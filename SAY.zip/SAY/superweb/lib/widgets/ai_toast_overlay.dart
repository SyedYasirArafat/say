import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../theme/app_theme.dart';
import '../providers/superweb_provider.dart';

// ===========================================================================
// AI TOAST OVERLAY
// Shows SAY-AI Governor notifications
// ===========================================================================

class AIToastOverlay extends StatelessWidget {
  const AIToastOverlay({super.key});

  @override
  Widget build(BuildContext context) {
    return Consumer<SuperwebProvider>(
      builder: (context, provider, child) {
        if (provider.toastQueue.isEmpty) {
          return const SizedBox.shrink();
        }
        
        return Positioned(
          top: MediaQuery.of(context).padding.top + 80,
          left: 16,
          right: 16,
          child: Column(
            children: provider.toastQueue.asMap().entries.map((entry) {
              return Padding(
                padding: const EdgeInsets.only(bottom: 8),
                child: _AIToast(
                  message: entry.value,
                  onDismiss: () => provider.clearToast(entry.key),
                  isCrisisMode: provider.isCrisisMode,
                ),
              );
            }).toList(),
          ),
        );
      },
    );
  }
}

class _AIToast extends StatefulWidget {
  final String message;
  final VoidCallback onDismiss;
  final bool isCrisisMode;

  const _AIToast({
    required this.message,
    required this.onDismiss,
    required this.isCrisisMode,
  });

  @override
  State<_AIToast> createState() => _AIToastState();
}

class _AIToastState extends State<_AIToast> 
    with SingleTickerProviderStateMixin {
  late AnimationController _controller;
  late Animation<Offset> _slideAnimation;
  late Animation<double> _fadeAnimation;

  @override
  void initState() {
    super.initState();
    _controller = AnimationController(
      duration: const Duration(milliseconds: 300),
      vsync: this,
    );
    
    _slideAnimation = Tween<Offset>(
      begin: const Offset(1, 0),
      end: Offset.zero,
    ).animate(CurvedAnimation(
      parent: _controller,
      curve: Curves.easeOutCubic,
    ));
    
    _fadeAnimation = Tween<double>(
      begin: 0,
      end: 1,
    ).animate(CurvedAnimation(
      parent: _controller,
      curve: Curves.easeOut,
    ));
    
    _controller.forward();
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return SlideTransition(
      position: _slideAnimation,
      child: FadeTransition(
        opacity: _fadeAnimation,
        child: Container(
          padding: const EdgeInsets.all(16),
          decoration: BoxDecoration(
            gradient: LinearGradient(
              colors: widget.isCrisisMode
                  ? [
                      AppTheme.crisisRed.withOpacity(0.9),
                      AppTheme.crisisRed.withOpacity(0.7),
                    ]
                  : [
                      AppTheme.bgElevated,
                      AppTheme.bgTertiary,
                    ],
              begin: Alignment.topLeft,
              end: Alignment.bottomRight,
            ),
            borderRadius: BorderRadius.circular(16),
            border: Border.all(
              color: widget.isCrisisMode 
                  ? AppTheme.crisisRed
                  : AppTheme.accentPrimary,
            ),
            boxShadow: [
              BoxShadow(
                color: (widget.isCrisisMode 
                    ? AppTheme.crisisRed 
                    : AppTheme.accentPrimary)
                    .withOpacity(0.3),
                blurRadius: 20,
                spreadRadius: 0,
              ),
            ],
          ),
          child: Row(
            children: [
              Container(
                padding: const EdgeInsets.all(8),
                decoration: BoxDecoration(
                  color: Colors.white.withOpacity(0.1),
                  borderRadius: BorderRadius.circular(8),
                ),
                child: const Text(
                  '🤖',
                  style: TextStyle(fontSize: 20),
                ),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Text(
                      'SAY-AI Governor',
                      style: TextStyle(
                        fontSize: 12,
                        fontWeight: FontWeight.w700,
                        color: widget.isCrisisMode 
                            ? Colors.white
                            : AppTheme.accentPrimary,
                      ),
                    ),
                    const SizedBox(height: 4),
                    Text(
                      widget.message,
                      style: TextStyle(
                        fontSize: 13,
                        color: widget.isCrisisMode 
                            ? Colors.white.withOpacity(0.9)
                            : AppTheme.textSecondary,
                      ),
                    ),
                  ],
                ),
              ),
              IconButton(
                onPressed: widget.onDismiss,
                icon: Icon(
                  Icons.close,
                  size: 18,
                  color: widget.isCrisisMode 
                      ? Colors.white.withOpacity(0.7)
                      : AppTheme.textMuted,
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

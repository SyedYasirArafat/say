import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../theme/app_theme.dart';
import '../providers/superweb_provider.dart';

// ===========================================================================
// BOTTOM NAVIGATION BAR
// Type selector for A, B, C, D, F modules
// ===========================================================================

class NavBottomBar extends StatelessWidget {
  const NavBottomBar({super.key});

  @override
  Widget build(BuildContext context) {
    return Consumer<SuperwebProvider>(
      builder: (context, provider, child) {
        return Container(
          decoration: BoxDecoration(
            color: AppTheme.bgSecondary,
            border: Border(
              top: BorderSide(
                color: provider.isCrisisMode 
                    ? AppTheme.crisisRed.withOpacity(0.3)
                    : AppTheme.glassBorder,
              ),
            ),
          ),
          child: SafeArea(
            child: Padding(
              padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 8),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceAround,
                children: [
                  _buildNavItem(
                    context,
                    provider,
                    type: 'a',
                    icon: '📺',
                    label: 'FlimXgo',
                    color: AppTheme.typeAColor,
                  ),
                  _buildNavItem(
                    context,
                    provider,
                    type: 'b',
                    icon: '💰',
                    label: 'Finance',
                    color: AppTheme.typeBColor,
                  ),
                  _buildNavItem(
                    context,
                    provider,
                    type: 'c',
                    icon: '🏛️',
                    label: 'GovConnect',
                    color: AppTheme.typeCColor,
                  ),
                  _buildNavItem(
                    context,
                    provider,
                    type: 'd',
                    icon: '⚖️',
                    label: 'Justice',
                    color: AppTheme.typeDColor,
                  ),
                  _buildNavItem(
                    context,
                    provider,
                    type: 'f',
                    icon: '📚',
                    label: 'Intellect',
                    color: AppTheme.typeFColor,
                  ),
                  _buildNavItem(
                    context,
                    provider,
                    type: 'e',
                    icon: '❤️',
                    label: 'Health',
                    color: AppTheme.typeEColor,
                  ),
                ],
              ),
            ),
          ),
        );
      },
    );
  }

  Widget _buildNavItem(
    BuildContext context,
    SuperwebProvider provider, {
    required String type,
    required String icon,
    required String label,
    required Color color,
  }) {
    final isActive = provider.activeModule == type;
    final isCrisis = provider.isCrisisMode;
    
    return GestureDetector(
      onTap: () => provider.switchModule(type),
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 200),
        padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
        decoration: BoxDecoration(
          color: isActive 
              ? (isCrisis ? AppTheme.crisisRed.withOpacity(0.2) : color.withOpacity(0.15))
              : Colors.transparent,
          borderRadius: BorderRadius.circular(12),
          border: Border.all(
            color: isActive 
                ? (isCrisis ? AppTheme.crisisRed : color)
                : Colors.transparent,
          ),
        ),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Text(
              icon,
              style: TextStyle(
                fontSize: isActive ? 24 : 20,
              ),
            ),
            const SizedBox(height: 4),
            Text(
              label,
              style: TextStyle(
                fontSize: 10,
                fontWeight: isActive ? FontWeight.w600 : FontWeight.w400,
                color: isActive 
                    ? (isCrisis ? AppTheme.crisisRed : color)
                    : AppTheme.textMuted,
              ),
            ),
          ],
        ),
      ),
    );
  }
}

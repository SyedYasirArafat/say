import 'package:flutter/material.dart';
import 'package:flutter/gestures.dart';

/// A widget that detects a "Z" gesture drawn on the screen
/// "The Z-Swipe": Top-Left -> Top-Right -> Bottom-Left -> Bottom-Right
class ZGestureDetector extends StatefulWidget {
  final Widget child;
  final VoidCallback onZGesture;

  const ZGestureDetector({
    super.key,
    required this.child,
    required this.onZGesture,
  });

  @override
  State<ZGestureDetector> createState() => _ZGestureDetectorState();
}

class _ZGestureDetectorState extends State<ZGestureDetector> {
  final List<Offset> _points = [];
  static const double _minDimension = 100.0; // Min size of Z
  double _lastVelocity = 0;

  void _onPanStart(DragStartDetails details) {
    _points.clear();
    _points.add(details.globalPosition);
  }

  void _onPanUpdate(DragUpdateDetails details) {
    _points.add(details.globalPosition);
    if (_points.length > 200) {
      _points.removeAt(0); // Keep buffer manageable
    }
  }

  void _onPanEnd(DragEndDetails details) {
    if (_detectZGesture()) {
      widget.onZGesture();
    }
    _points.clear();
  }

  bool _detectZGesture() {
    if (_points.length < 10) return false;

    // 1. Check bounds
    double minX = double.infinity, maxX = -double.infinity;
    double minY = double.infinity, maxY = -double.infinity;

    for (var p in _points) {
      if (p.dx < minX) minX = p.dx;
      if (p.dx > maxX) maxX = p.dx;
      if (p.dy < minY) minY = p.dy;
      if (p.dy > maxY) maxY = p.dy;
    }

    final width = maxX - minX;
    final height = maxY - minY;

    if (width < _minDimension || height < _minDimension) return false;

    // 2. Simplified Vector Analysis for "Z"
    // Segment 1: Left to Right (Top)
    // Segment 2: Right to Left-Down (Diagonal)
    // Segment 3: Left to Right (Bottom)
    
    // We break the stroke into 3 roughly equal parts
    int n = _points.length;
    int p1 = (n * 0.33).round();
    int p2 = (n * 0.66).round();

    // Vectors
    Offset start = _points.first;
    Offset mid1 = _points[p1];
    Offset mid2 = _points[p2];
    Offset end = _points.last;

    Offset v1 = mid1 - start; // Should be Right (+x, ~0y)
    Offset v2 = mid2 - mid1;  // Should be Down-Left (-x, +y)
    Offset v3 = end - mid2;   // Should be Right (+x, ~0y)

    // Check Directions
    bool isSeg1Right = v1.dx > 20 && v1.dy.abs() < v1.dx.abs();
    bool isSeg2Diagonal = v2.dx < -20 && v2.dy > 20;
    bool isSeg3Right = v3.dx > 20 && v3.dy.abs() < v3.dx.abs();

    return isSeg1Right && isSeg2Diagonal && isSeg3Right;
  }

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onPanStart: _onPanStart,
      onPanUpdate: _onPanUpdate,
      onPanEnd: _onPanEnd,
      behavior: HitTestBehavior.translucent, // Allow pass-through
      child: widget.child,
    );
  }
}

import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:flutter_animate/flutter_animate.dart';
import 'package:glassmorphism/glassmorphism.dart';
import 'package:iconsax/iconsax.dart';

import '../theme/app_theme.dart';
import '../providers/superweb_provider.dart';

class TypeEScreen extends StatelessWidget {
  const TypeEScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Consumer<SuperwebProvider>(
      builder: (context, provider, child) {
        final data = provider.healthRecord;
        final isPanic = provider.isPanicMode;

        return SingleChildScrollView(
          padding: const EdgeInsets.all(16),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              // HEADER
              Row(
                children: [
                   Container(
                    padding: const EdgeInsets.all(10),
                    decoration: BoxDecoration(
                      color: AppTheme.typeEColor.withOpacity(0.2),
                      borderRadius: BorderRadius.circular(12),
                    ),
                    child: const Icon(Icons.favorite, color: AppTheme.typeEColor),
                  ),
                  const SizedBox(width: 12),
                  Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        'SAY Vitality',
                        style: TextStyle(
                          fontSize: 20,
                          fontWeight: FontWeight.bold,
                          color: AppTheme.textPrimary,
                        ),
                      ),
                      Text(
                        'Health & Emergency Layer',
                        style: TextStyle(
                          fontSize: 12,
                          color: AppTheme.textMuted,
                        ),
                      ),
                    ],
                  ),
                ],
              ),

              const SizedBox(height: 24),

              // PANIC MODE UI
              if (isPanic)
                Container(
                  width: double.infinity,
                  padding: const EdgeInsets.all(20),
                  margin: const EdgeInsets.only(bottom: 24),
                  decoration: BoxDecoration(
                    color: AppTheme.crisisRed,
                    borderRadius: BorderRadius.circular(20),
                    boxShadow: [
                      BoxShadow(
                        color: AppTheme.crisisRed.withOpacity(0.5),
                        blurRadius: 30,
                        spreadRadius: 5,
                      )
                    ],
                  ),
                  child: Column(
                    children: [
                      const Icon(Icons.warning_amber_rounded,
                          size: 48, color: Colors.white),
                      const SizedBox(height: 12),
                      const Text(
                        "MEDICAL EMERGENCY DETECTED",
                        style: TextStyle(
                          fontSize: 18,
                          fontWeight: FontWeight.w900,
                          color: Colors.white,
                          letterSpacing: 1.5,
                        ),
                      ),
                      const SizedBox(height: 8),
                      const Text(
                        "Broadcasting GPS • Alerting Kin • Unlocking Funds",
                        style: TextStyle(color: Colors.white70, fontSize: 12),
                      ),
                      const SizedBox(height: 20),
                      ElevatedButton(
                        style: ElevatedButton.styleFrom(
                          backgroundColor: Colors.white,
                          foregroundColor: AppTheme.crisisRed,
                        ),
                        onPressed: provider.resetPanicMode,
                        child: const Text("I AM SAFE (CANCEL)"),
                      ),
                    ],
                  ),
                ).animate(onPlay: (c) => c.repeat(reverse: true))
                 .scaleXY(begin: 1.0, end: 1.05, duration: 1.seconds),

              // VITALS CARD
              GlassmorphicContainer(
                width: double.infinity,
                height: 180,
                borderRadius: 20,
                blur: 20,
                alignment: Alignment.center,
                border: 2,
                linearGradient: AppTheme.glassGradient,
                borderGradient: AppTheme.borderGradient,
                child: Padding(
                    padding: const EdgeInsets.all(20),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            Text("LIVE VITALS", style: AppTheme.h3),
                            Container(
                              padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                              decoration: BoxDecoration(
                                color: AppTheme.success.withOpacity(0.2),
                                borderRadius: BorderRadius.circular(8),
                              ),
                              child: const Text("Connected", style: TextStyle(color: AppTheme.success, fontSize: 10)),
                            )
                          ],
                        ),
                        const SizedBox(height: 20),
                        Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: data.metrics.map((m) => _buildMetric(m)).toList(),
                        )
                      ],
                    ),
                ),
              ),

              const SizedBox(height: 20),
              
              // MEDICAL ID CARD
              Text("EMERGENCY ID", style: AppTheme.h3),
              const SizedBox(height: 12),
              Container(
                padding: const EdgeInsets.all(16),
                decoration: BoxDecoration(
                  color: AppTheme.bgElevated,
                  borderRadius: BorderRadius.circular(16),
                  border: Border.all(color: AppTheme.glassBorder),
                ),
                child: Row(
                  children: [
                    _buildIdField("Blood Type", data.bloodType, Icons.bloodtype, Colors.red),
                    _buildIdField("Insurance", "ACTIVE", Icons.shield, Colors.blue),
                    _buildIdField("Contact", "Ammi", Icons.phone, Colors.green),
                  ],
                ),
              ),

              const SizedBox(height: 24),

              // PANIC BUTTON TRIGGER (Simulation)
              Center(
                child: GestureDetector(
                  onLongPress: provider.triggerPanicMode,
                  child: Container(
                    width: 80,
                    height: 80,
                    decoration: BoxDecoration(
                      shape: BoxShape.circle,
                      color: AppTheme.bgTertiary,
                      border: Border.all(color: AppTheme.typeEColor, width: 2),
                      boxShadow: [
                        BoxShadow(
                          color: AppTheme.typeEColor.withOpacity(0.2),
                          blurRadius: 20,
                        )
                      ],
                    ),
                    child: const Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Icon(Icons.touch_app, color: AppTheme.typeEColor),
                        Text("HOLD", style: TextStyle(fontSize: 10, color: AppTheme.typeEColor, fontWeight: FontWeight.bold))
                      ],
                    ),
                  ),
                ),
              ),
              const SizedBox(height: 8),
              const Center(child: Text("Long Press to Simulate Panic Mode", style: TextStyle(color: AppTheme.textMuted, fontSize: 10))),
            ],
          ),
        );
      },
    );
  }

  Widget _buildMetric(metric) {
    final color = metric.status == 'NORMAL' ? AppTheme.success : AppTheme.warning;
    return Column(
      children: [
        Text(metric.label, style: const TextStyle(color: AppTheme.textMuted, fontSize: 12)),
        const SizedBox(height: 4),
        Text(metric.value, style: TextStyle(color: color, fontSize: 18, fontWeight: FontWeight.bold)),
        const SizedBox(height: 4),
        Icon(
          metric.trend == 'UP' ? Icons.trending_up : (metric.trend == 'DOWN' ? Icons.trending_down : Icons.trending_flat),
          size: 14,
          color: AppTheme.textMuted,
        )
      ],
    );
  }

  Widget _buildIdField(String label, String value, IconData icon, Color color) {
    return Expanded(
      child: Column(
        children: [
          Icon(icon, color: color, size: 24),
          const SizedBox(height: 8),
          Text(label, style: const TextStyle(color: AppTheme.textMuted, fontSize: 10)),
          Text(value, style: const TextStyle(color: AppTheme.textPrimary, fontSize: 12, fontWeight: FontWeight.bold)),
        ],
      ),
    );
  }
}

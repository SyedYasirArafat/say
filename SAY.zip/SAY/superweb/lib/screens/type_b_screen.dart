import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../theme/app_theme.dart';
import '../providers/superweb_provider.dart';
import '../data/mock_data.dart';

// ===========================================================================
// TYPE B SCREEN - SAY FINANCE (Economy & Wealth)
// ===========================================================================

class TypeBScreen extends StatelessWidget {
  const TypeBScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Consumer<SuperwebProvider>(
      builder: (context, provider, child) {
        final finance = provider.financePortfolio;
        
        return ListView(
          padding: const EdgeInsets.all(16),
          children: [
            // Section Header
            _buildSectionHeader(context, '💰 SAY Finance', 'Earn • Trade • Grow'),
            
            const SizedBox(height: 16),
            
            // Portfolio Card
            _buildPortfolioCard(context, finance, provider),
            
            const SizedBox(height: 24),
            
            // Salary Status (Crisis indicator)
            _buildSalaryStatus(context, finance.salaryStatus, provider.isCrisisMode),
            
            const SizedBox(height: 24),
            
            // Holdings
            _buildHoldings(context, finance.holdings),
            
            const SizedBox(height: 24),
            
            // Subscriptions
            _buildSubscriptions(context, provider),
            
            const SizedBox(height: 24),
            
            // Gig-Hub CTA (emphasized in crisis mode)
            if (provider.isCrisisMode)
              _buildGigHubCTA(context),
            
            const SizedBox(height: 100), // Bottom padding
          ],
        );
      },
    );
  }

  Widget _buildSectionHeader(BuildContext context, String title, String subtitle) {
    return Row(
      children: [
        Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(title, style: Theme.of(context).textTheme.headlineMedium),
            Text(subtitle, style: Theme.of(context).textTheme.bodySmall),
          ],
        ),
      ],
    );
  }

  Widget _buildPortfolioCard(
    BuildContext context,
    FinancePortfolio finance,
    SuperwebProvider provider,
  ) {
    return Container(
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        gradient: LinearGradient(
          colors: provider.isCrisisMode
              ? [
                  AppTheme.crisisRed.withOpacity(0.15),
                  Colors.transparent,
                ]
              : [
                  AppTheme.typeBColor.withOpacity(0.15),
                  Colors.transparent,
                ],
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
        ),
        borderRadius: BorderRadius.circular(20),
        border: Border.all(
          color: provider.isCrisisMode ? AppTheme.crisisRed : AppTheme.typeBColor,
        ),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            'Total Balance',
            style: Theme.of(context).textTheme.bodySmall,
          ),
          const SizedBox(height: 8),
          Row(
            crossAxisAlignment: CrossAxisAlignment.end,
            children: [
              Text(
                '₹${finance.currentBalance.toStringAsFixed(0)}',
                style: Theme.of(context).textTheme.displaySmall?.copyWith(
                  fontWeight: FontWeight.w800,
                  color: provider.isCrisisMode ? AppTheme.crisisRed : AppTheme.textPrimary,
                ),
              ),
              const SizedBox(width: 8),
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                decoration: BoxDecoration(
                  color: provider.isCrisisMode 
                      ? AppTheme.crisisRed.withOpacity(0.2)
                      : AppTheme.success.withOpacity(0.2),
                  borderRadius: BorderRadius.circular(6),
                ),
                child: Text(
                  provider.isCrisisMode ? '⚠️ At Risk' : '+₹12,340 today',
                  style: TextStyle(
                    fontSize: 12,
                    fontWeight: FontWeight.w600,
                    color: provider.isCrisisMode ? AppTheme.crisisRed : AppTheme.success,
                  ),
                ),
              ),
            ],
          ),
          const SizedBox(height: 16),
          
          // Mini chart placeholder
          Container(
            height: 60,
            decoration: BoxDecoration(
              color: AppTheme.bgTertiary,
              borderRadius: BorderRadius.circular(8),
            ),
            child: CustomPaint(
              size: const Size(double.infinity, 60),
              painter: _ChartPainter(
                color: provider.isCrisisMode ? AppTheme.crisisRed : AppTheme.typeBColor,
              ),
            ),
          ),
          
          const SizedBox(height: 16),
          
          Row(
            children: [
              _buildStatItem('Runway', '${provider.runwayMonths.toStringAsFixed(1)} mo', 
                  provider.isCrisisMode ? AppTheme.crisisRed : AppTheme.textSecondary),
              const SizedBox(width: 24),
              _buildStatItem('Credit Score', '${finance.creditScore}', AppTheme.success),
              const SizedBox(width: 24),
              _buildStatItem('Burn Rate', '₹${finance.monthlyBurnRate.toInt()}/mo', AppTheme.warning),
            ],
          ),
        ],
      ),
    );
  }

  Widget _buildStatItem(String label, String value, Color valueColor) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          label,
          style: const TextStyle(fontSize: 10, color: AppTheme.textMuted),
        ),
        Text(
          value,
          style: TextStyle(
            fontSize: 14,
            fontWeight: FontWeight.w700,
            color: valueColor,
          ),
        ),
      ],
    );
  }

  Widget _buildSalaryStatus(
    BuildContext context,
    SalaryStatus salary,
    bool isCrisisMode,
  ) {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: isCrisisMode 
            ? AppTheme.crisisRed.withOpacity(0.1)
            : AppTheme.glassBg,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(
          color: isCrisisMode ? AppTheme.crisisRed : AppTheme.glassBorder,
          width: isCrisisMode ? 2 : 1,
        ),
      ),
      child: Row(
        children: [
          Container(
            padding: const EdgeInsets.all(10),
            decoration: BoxDecoration(
              color: isCrisisMode 
                  ? AppTheme.crisisRed.withOpacity(0.2)
                  : AppTheme.success.withOpacity(0.2),
              borderRadius: BorderRadius.circular(10),
            ),
            child: Text(
              isCrisisMode ? '🚨' : '💼',
              style: const TextStyle(fontSize: 20),
            ),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  salary.employer,
                  style: Theme.of(context).textTheme.titleSmall,
                ),
                Text(
                  isCrisisMode 
                      ? '${salary.daysOverdue} days overdue'
                      : 'Expected: ${_formatDate(salary.expectedDate)}',
                  style: TextStyle(
                    fontSize: 12,
                    color: isCrisisMode ? AppTheme.crisisRed : AppTheme.textMuted,
                  ),
                ),
              ],
            ),
          ),
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
            decoration: BoxDecoration(
              color: isCrisisMode 
                  ? AppTheme.crisisRed
                  : AppTheme.success,
              borderRadius: BorderRadius.circular(20),
            ),
            child: Text(
              salary.status.replaceAll('_', ' '),
              style: const TextStyle(
                fontSize: 10,
                fontWeight: FontWeight.w700,
                color: Colors.white,
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildHoldings(BuildContext context, List<StockHolding> holdings) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text('📈 Holdings', style: Theme.of(context).textTheme.titleMedium),
        const SizedBox(height: 12),
        ...holdings.map((h) => Container(
          margin: const EdgeInsets.only(bottom: 8),
          padding: const EdgeInsets.all(16),
          decoration: AppTheme.glassDecoration,
          child: Row(
            children: [
              Container(
                width: 44,
                height: 44,
                decoration: BoxDecoration(
                  color: AppTheme.bgTertiary,
                  borderRadius: BorderRadius.circular(10),
                ),
                child: Center(
                  child: Text(
                    h.ticker[0],
                    style: const TextStyle(
                      fontSize: 18,
                      fontWeight: FontWeight.w700,
                      color: AppTheme.typeBColor,
                    ),
                  ),
                ),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(h.ticker, style: Theme.of(context).textTheme.titleSmall),
                    Text(
                      '${h.qty} shares @ ₹${h.avgBuy}',
                      style: Theme.of(context).textTheme.bodySmall,
                    ),
                  ],
                ),
              ),
              Column(
                crossAxisAlignment: CrossAxisAlignment.end,
                children: [
                  Text(
                    '₹${h.currentValue.toStringAsFixed(0)}',
                    style: Theme.of(context).textTheme.titleSmall,
                  ),
                  Text(
                    '${h.pnlPercent >= 0 ? '+' : ''}${h.pnlPercent}%',
                    style: TextStyle(
                      fontSize: 12,
                      fontWeight: FontWeight.w600,
                      color: h.pnlPercent >= 0 ? AppTheme.success : AppTheme.error,
                    ),
                  ),
                ],
              ),
            ],
          ),
        )),
      ],
    );
  }

  Widget _buildSubscriptions(BuildContext context, SuperwebProvider provider) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Row(
          children: [
            Text('💳 Subscriptions', style: Theme.of(context).textTheme.titleMedium),
            const Spacer(),
            Text(
              '₹${provider.totalSubscriptionCost.toInt()}/mo',
              style: Theme.of(context).textTheme.titleSmall?.copyWith(
                color: AppTheme.textMuted,
              ),
            ),
          ],
        ),
        const SizedBox(height: 12),
        ...provider.subscriptions.map((s) {
          final isPaused = s.status == 'PAUSED';
          return Container(
            margin: const EdgeInsets.only(bottom: 8),
            padding: const EdgeInsets.all(12),
            decoration: BoxDecoration(
              color: isPaused 
                  ? AppTheme.crisisRed.withOpacity(0.05)
                  : AppTheme.glassBg,
              borderRadius: BorderRadius.circular(12),
              border: Border.all(
                color: isPaused 
                    ? AppTheme.crisisRed.withOpacity(0.3)
                    : AppTheme.glassBorder,
              ),
            ),
            child: Row(
              children: [
                Text(
                  s.name,
                  style: TextStyle(
                    fontSize: 14,
                    fontWeight: FontWeight.w500,
                    color: isPaused ? AppTheme.textMuted : AppTheme.textPrimary,
                    decoration: isPaused ? TextDecoration.lineThrough : null,
                  ),
                ),
                const Spacer(),
                Text(
                  '₹${s.cost.toInt()}',
                  style: TextStyle(
                    fontSize: 14,
                    color: isPaused ? AppTheme.textMuted : AppTheme.textSecondary,
                  ),
                ),
                const SizedBox(width: 8),
                Container(
                  padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                  decoration: BoxDecoration(
                    color: isPaused 
                        ? AppTheme.crisisRed.withOpacity(0.2)
                        : AppTheme.success.withOpacity(0.2),
                    borderRadius: BorderRadius.circular(6),
                  ),
                  child: Text(
                    s.status,
                    style: TextStyle(
                      fontSize: 10,
                      fontWeight: FontWeight.w600,
                      color: isPaused ? AppTheme.crisisRed : AppTheme.success,
                    ),
                  ),
                ),
              ],
            ),
          );
        }),
      ],
    );
  }

  Widget _buildGigHubCTA(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        gradient: LinearGradient(
          colors: [
            AppTheme.success.withOpacity(0.2),
            AppTheme.success.withOpacity(0.05),
          ],
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
        ),
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: AppTheme.success),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              const Text('💼', style: TextStyle(fontSize: 24)),
              const SizedBox(width: 12),
              Text(
                'Gig-Hub',
                style: Theme.of(context).textTheme.titleMedium?.copyWith(
                  color: AppTheme.success,
                ),
              ),
              const Spacer(),
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                decoration: BoxDecoration(
                  color: AppTheme.success,
                  borderRadius: BorderRadius.circular(12),
                ),
                child: const Text(
                  '3 Urgent',
                  style: TextStyle(
                    fontSize: 10,
                    fontWeight: FontWeight.w700,
                    color: Colors.white,
                  ),
                ),
              ),
            ],
          ),
          const SizedBox(height: 12),
          Text(
            'Find quick gigs to bridge your income gap',
            style: Theme.of(context).textTheme.bodyMedium,
          ),
          const SizedBox(height: 16),
          SizedBox(
            width: double.infinity,
            child: ElevatedButton(
              onPressed: () => _showGigHubBottomSheet(context),
              style: ElevatedButton.styleFrom(
                backgroundColor: AppTheme.success,
              ),
              child: const Text('Browse Available Gigs →'),
            ),
          ),
        ],
      ),
    );
  }

  void _showGigHubBottomSheet(BuildContext context) {
    final gigs = [
      {
        'title': 'Flutter App Development',
        'company': 'TechStart India',
        'budget': '₹80,000',
        'duration': '2 weeks',
        'skills': ['Flutter', 'Dart', 'Firebase'],
        'urgent': true,
      },
      {
        'title': 'Architecture Consultation',
        'company': 'BuildRight Pvt Ltd',
        'budget': '₹45,000',
        'duration': '1 week',
        'skills': ['AutoCAD', 'Design Review'],
        'urgent': true,
      },
      {
        'title': 'UI/UX Design Project',
        'company': 'DesignHub',
        'budget': '₹25,000',
        'duration': '5 days',
        'skills': ['Figma', 'UI Design'],
        'urgent': true,
      },
      {
        'title': 'Technical Documentation',
        'company': 'DocuPro',
        'budget': '₹15,000',
        'duration': '3 days',
        'skills': ['Writing', 'Technical'],
        'urgent': false,
      },
    ];

    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.transparent,
      builder: (context) => Container(
        height: MediaQuery.of(context).size.height * 0.75,
        decoration: const BoxDecoration(
          color: AppTheme.bgSecondary,
          borderRadius: BorderRadius.vertical(top: Radius.circular(24)),
        ),
        child: Column(
          children: [
            // Handle bar
            Container(
              margin: const EdgeInsets.only(top: 12),
              width: 40,
              height: 4,
              decoration: BoxDecoration(
                color: AppTheme.textMuted,
                borderRadius: BorderRadius.circular(2),
              ),
            ),
            
            // Header
            Padding(
              padding: const EdgeInsets.all(20),
              child: Row(
                children: [
                  const Text('💼', style: TextStyle(fontSize: 28)),
                  const SizedBox(width: 12),
                  Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        'Gig-Hub',
                        style: Theme.of(context).textTheme.titleLarge,
                      ),
                      Text(
                        '${gigs.length} gigs matching your skills',
                        style: Theme.of(context).textTheme.bodySmall,
                      ),
                    ],
                  ),
                  const Spacer(),
                  IconButton(
                    onPressed: () => Navigator.pop(context),
                    icon: const Icon(Icons.close),
                  ),
                ],
              ),
            ),
            
            const Divider(height: 1, color: AppTheme.glassBorder),
            
            // Gig List
            Expanded(
              child: ListView.separated(
                padding: const EdgeInsets.all(16),
                itemCount: gigs.length,
                separatorBuilder: (_, __) => const SizedBox(height: 12),
                itemBuilder: (context, index) {
                  final gig = gigs[index];
                  return Container(
                    padding: const EdgeInsets.all(16),
                    decoration: BoxDecoration(
                      color: AppTheme.glassBg,
                      borderRadius: BorderRadius.circular(16),
                      border: Border.all(
                        color: gig['urgent'] == true 
                            ? AppTheme.success.withOpacity(0.5)
                            : AppTheme.glassBorder,
                      ),
                    ),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Row(
                          children: [
                            Expanded(
                              child: Text(
                                gig['title'] as String,
                                style: Theme.of(context).textTheme.titleSmall,
                              ),
                            ),
                            if (gig['urgent'] == true)
                              Container(
                                padding: const EdgeInsets.symmetric(
                                  horizontal: 8,
                                  vertical: 4,
                                ),
                                decoration: BoxDecoration(
                                  color: AppTheme.error.withOpacity(0.2),
                                  borderRadius: BorderRadius.circular(8),
                                ),
                                child: const Row(
                                  mainAxisSize: MainAxisSize.min,
                                  children: [
                                    Text('🔥', style: TextStyle(fontSize: 10)),
                                    SizedBox(width: 4),
                                    Text(
                                      'URGENT',
                                      style: TextStyle(
                                        fontSize: 9,
                                        fontWeight: FontWeight.w700,
                                        color: AppTheme.error,
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                          ],
                        ),
                        const SizedBox(height: 4),
                        Text(
                          gig['company'] as String,
                          style: Theme.of(context).textTheme.bodySmall,
                        ),
                        const SizedBox(height: 12),
                        Row(
                          children: [
                            Text(
                              gig['budget'] as String,
                              style: const TextStyle(
                                fontSize: 18,
                                fontWeight: FontWeight.w800,
                                color: AppTheme.success,
                              ),
                            ),
                            const SizedBox(width: 12),
                            Text(
                              '• ${gig['duration']}',
                              style: Theme.of(context).textTheme.bodySmall,
                            ),
                          ],
                        ),
                        const SizedBox(height: 12),
                        Wrap(
                          spacing: 6,
                          runSpacing: 6,
                          children: (gig['skills'] as List<String>).map((skill) {
                            return Container(
                              padding: const EdgeInsets.symmetric(
                                horizontal: 8,
                                vertical: 4,
                              ),
                              decoration: BoxDecoration(
                                color: AppTheme.bgTertiary,
                                borderRadius: BorderRadius.circular(6),
                              ),
                              child: Text(
                                skill,
                                style: const TextStyle(
                                  fontSize: 11,
                                  color: AppTheme.textSecondary,
                                ),
                              ),
                            );
                          }).toList(),
                        ),
                        const SizedBox(height: 12),
                        SizedBox(
                          width: double.infinity,
                          child: ElevatedButton(
                            onPressed: () {
                              Navigator.pop(context);
                              ScaffoldMessenger.of(context).showSnackBar(
                                SnackBar(
                                  content: Text('Applied to: ${gig['title']}'),
                                  backgroundColor: AppTheme.success,
                                ),
                              );
                            },
                            style: ElevatedButton.styleFrom(
                              backgroundColor: AppTheme.success,
                              padding: const EdgeInsets.symmetric(vertical: 12),
                            ),
                            child: const Text('Apply Now'),
                          ),
                        ),
                      ],
                    ),
                  );
                },
              ),
            ),
          ],
        ),
      ),
    );
  }

  String _formatDate(DateTime date) {
    return '${date.day}/${date.month}/${date.year}';
  }
}

// Simple chart painter
class _ChartPainter extends CustomPainter {
  final Color color;

  _ChartPainter({required this.color});

  @override
  void paint(Canvas canvas, Size size) {
    final paint = Paint()
      ..color = color
      ..style = PaintingStyle.stroke
      ..strokeWidth = 2;

    final path = Path();
    path.moveTo(0, size.height * 0.8);
    path.quadraticBezierTo(
      size.width * 0.2, size.height * 0.6,
      size.width * 0.4, size.height * 0.7,
    );
    path.quadraticBezierTo(
      size.width * 0.6, size.height * 0.5,
      size.width * 0.8, size.height * 0.3,
    );
    path.quadraticBezierTo(
      size.width * 0.9, size.height * 0.2,
      size.width, size.height * 0.1,
    );

    canvas.drawPath(path, paint);

    // Fill gradient
    final fillPath = Path.from(path);
    fillPath.lineTo(size.width, size.height);
    fillPath.lineTo(0, size.height);
    fillPath.close();

    final fillPaint = Paint()
      ..shader = LinearGradient(
        begin: Alignment.topCenter,
        end: Alignment.bottomCenter,
        colors: [color.withOpacity(0.3), color.withOpacity(0)],
      ).createShader(Rect.fromLTWH(0, 0, size.width, size.height));

    canvas.drawPath(fillPath, fillPaint);
  }

  @override
  bool shouldRepaint(covariant CustomPainter oldDelegate) => false;
}

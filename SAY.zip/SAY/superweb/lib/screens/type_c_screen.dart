import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../theme/app_theme.dart';
import '../providers/superweb_provider.dart';

// ===========================================================================
// TYPE C SCREEN - GOVCONNECT (Citizen & Government)
// ===========================================================================

class TypeCScreen extends StatelessWidget {
  const TypeCScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Consumer<SuperwebProvider>(
      builder: (context, provider, child) {
        final user = provider.userProfile;
        
        return ListView(
          padding: const EdgeInsets.all(16),
          children: [
            // Section Header
            _buildSectionHeader(context, '🏛️ GovConnect', 'Identity • Vote • Access'),
            
            const SizedBox(height: 16),
            
            // SAY-ID Card
            _buildSayIdCard(context, user),
            
            const SizedBox(height: 24),
            
            // Linked Documents
            _buildLinkedDocuments(context, user.linkedIds),
            
            const SizedBox(height: 24),
            
            // Voter Status
            _buildVoterStatus(context, user.voterStatus),
            
            const SizedBox(height: 24),
            
            // Trust Level
            _buildTrustLevel(context, user.sayIdTrustLevel),
            
            const SizedBox(height: 100),
          ],
        );
      },
    );
  }

  Widget _buildSectionHeader(BuildContext context, String title, String subtitle) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(title, style: Theme.of(context).textTheme.headlineMedium),
        Text(subtitle, style: Theme.of(context).textTheme.bodySmall),
      ],
    );
  }

  Widget _buildSayIdCard(BuildContext context, dynamic user) {
    return Container(
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        gradient: LinearGradient(
          colors: [
            AppTheme.typeCColor.withOpacity(0.2),
            AppTheme.typeCColor.withOpacity(0.05),
          ],
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
        ),
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: AppTheme.typeCColor, width: 2),
        boxShadow: [
          BoxShadow(
            color: AppTheme.typeCColor.withOpacity(0.2),
            blurRadius: 30,
            spreadRadius: 0,
          ),
        ],
      ),
      child: Column(
        children: [
          // Header
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
                decoration: BoxDecoration(
                  color: AppTheme.success,
                  borderRadius: BorderRadius.circular(20),
                ),
                child: const Row(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Icon(Icons.verified, size: 14, color: Colors.white),
                    SizedBox(width: 4),
                    Text(
                      'VERIFIED',
                      style: TextStyle(
                        fontSize: 10,
                        fontWeight: FontWeight.w700,
                        color: Colors.white,
                        letterSpacing: 1,
                      ),
                    ),
                  ],
                ),
              ),
              Text(
                'SAY-ID',
                style: TextStyle(
                  fontSize: 12,
                  fontWeight: FontWeight.w600,
                  color: AppTheme.textMuted,
                  letterSpacing: 2,
                ),
              ),
            ],
          ),
          
          const SizedBox(height: 20),
          
          // Profile Section
          Row(
            children: [
              // Photo
              Container(
                width: 80,
                height: 100,
                decoration: BoxDecoration(
                  color: AppTheme.bgTertiary,
                  borderRadius: BorderRadius.circular(12),
                  border: Border.all(color: AppTheme.glassBorder),
                ),
                child: const Center(
                  child: Text('👤', style: TextStyle(fontSize: 32)),
                ),
              ),
              
              const SizedBox(width: 16),
              
              // Details
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      user.fullName,
                      style: Theme.of(context).textTheme.titleLarge?.copyWith(
                        fontWeight: FontWeight.w700,
                      ),
                    ),
                    const SizedBox(height: 4),
                    Text(
                      user.uuid,
                      style: TextStyle(
                        fontFamily: 'monospace',
                        fontSize: 11,
                        color: AppTheme.textMuted,
                      ),
                    ),
                    const SizedBox(height: 8),
                    Row(
                      children: [
                        _buildIdBadge('🇮🇳', user.citizenship),
                        const SizedBox(width: 8),
                        _buildIdBadge('⭐', 'Trust ${user.sayIdTrustLevel}/5'),
                      ],
                    ),
                  ],
                ),
              ),
              
              // QR Code
              Container(
                width: 64,
                height: 64,
                decoration: BoxDecoration(
                  color: Colors.white,
                  borderRadius: BorderRadius.circular(8),
                ),
                child: const Center(
                  child: Text('📱', style: TextStyle(fontSize: 28)),
                ),
              ),
            ],
          ),
          
          const SizedBox(height: 16),
          
          // KYC Status
          Container(
            width: double.infinity,
            padding: const EdgeInsets.all(12),
            decoration: BoxDecoration(
              color: AppTheme.typeCColor.withOpacity(0.1),
              borderRadius: BorderRadius.circular(10),
            ),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                const Icon(Icons.shield, size: 16, color: AppTheme.typeCColor),
                const SizedBox(width: 8),
                Text(
                  user.kycStatus.replaceAll('_', ' '),
                  style: const TextStyle(
                    fontSize: 12,
                    fontWeight: FontWeight.w700,
                    color: AppTheme.typeCColor,
                    letterSpacing: 1,
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildIdBadge(String icon, String label) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
      decoration: BoxDecoration(
        color: AppTheme.glassBg,
        borderRadius: BorderRadius.circular(6),
        border: Border.all(color: AppTheme.glassBorder),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Text(icon, style: const TextStyle(fontSize: 12)),
          const SizedBox(width: 4),
          Text(
            label,
            style: const TextStyle(
              fontSize: 10,
              color: AppTheme.textSecondary,
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildLinkedDocuments(BuildContext context, dynamic linkedIds) {
    final docs = [
      {'icon': '🪪', 'name': 'Aadhaar', 'value': '****${linkedIds.aadhaarLast4}', 'status': 'Linked'},
      {'icon': '💳', 'name': 'PAN Card', 'value': 'Encrypted', 'status': 'Verified'},
      {'icon': '📕', 'name': 'Passport', 'value': linkedIds.passportStatus.replaceAll('_', ' '), 'status': 'Active'},
    ];

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text('🔐 Linked Documents', style: Theme.of(context).textTheme.titleMedium),
        const SizedBox(height: 12),
        ...docs.map((doc) => Container(
          margin: const EdgeInsets.only(bottom: 8),
          padding: const EdgeInsets.all(16),
          decoration: AppTheme.glassDecoration,
          child: Row(
            children: [
              Text(doc['icon']!, style: const TextStyle(fontSize: 24)),
              const SizedBox(width: 12),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      doc['name']!,
                      style: Theme.of(context).textTheme.titleSmall,
                    ),
                    Text(
                      doc['value']!,
                      style: Theme.of(context).textTheme.bodySmall,
                    ),
                  ],
                ),
              ),
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
                decoration: BoxDecoration(
                  color: AppTheme.success.withOpacity(0.2),
                  borderRadius: BorderRadius.circular(20),
                ),
                child: Text(
                  doc['status']!,
                  style: const TextStyle(
                    fontSize: 10,
                    fontWeight: FontWeight.w600,
                    color: AppTheme.success,
                  ),
                ),
              ),
            ],
          ),
        )),
      ],
    );
  }

  Widget _buildVoterStatus(BuildContext context, dynamic voter) {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: AppTheme.glassDecorationWithGlow(AppTheme.typeCColor),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              const Text('🗳️', style: TextStyle(fontSize: 24)),
              const SizedBox(width: 12),
              Text(
                'Voter Status',
                style: Theme.of(context).textTheme.titleMedium,
              ),
              const Spacer(),
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
                decoration: BoxDecoration(
                  color: voter.registered 
                      ? AppTheme.success.withOpacity(0.2)
                      : AppTheme.error.withOpacity(0.2),
                  borderRadius: BorderRadius.circular(20),
                ),
                child: Text(
                  voter.registered ? 'REGISTERED' : 'NOT REGISTERED',
                  style: TextStyle(
                    fontSize: 10,
                    fontWeight: FontWeight.w700,
                    color: voter.registered ? AppTheme.success : AppTheme.error,
                  ),
                ),
              ),
            ],
          ),
          const SizedBox(height: 16),
          Row(
            children: [
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    const Text(
                      'Constituency',
                      style: TextStyle(fontSize: 10, color: AppTheme.textMuted),
                    ),
                    Text(
                      voter.constituency,
                      style: Theme.of(context).textTheme.titleSmall,
                    ),
                  ],
                ),
              ),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    const Text(
                      'Last Voted',
                      style: TextStyle(fontSize: 10, color: AppTheme.textMuted),
                    ),
                    Text(
                      '${voter.lastVoted.day}/${voter.lastVoted.month}/${voter.lastVoted.year}',
                      style: Theme.of(context).textTheme.titleSmall,
                    ),
                  ],
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }

  Widget _buildTrustLevel(BuildContext context, int level) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text('⭐ Trust Level', style: Theme.of(context).textTheme.titleMedium),
        const SizedBox(height: 12),
        Container(
          padding: const EdgeInsets.all(16),
          decoration: AppTheme.glassDecoration,
          child: Column(
            children: [
              Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: List.generate(5, (index) {
                  return Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 4),
                    child: Icon(
                      Icons.star,
                      size: 32,
                      color: index < level 
                          ? AppTheme.accentPrimary
                          : AppTheme.textMuted.withOpacity(0.3),
                    ),
                  );
                }),
              ),
              const SizedBox(height: 12),
              Text(
                'Level $level - Maximum Trust',
                style: Theme.of(context).textTheme.titleSmall?.copyWith(
                  color: AppTheme.accentPrimary,
                ),
              ),
              const SizedBox(height: 4),
              Text(
                'All documents verified • Clean record • Active citizen',
                style: Theme.of(context).textTheme.bodySmall,
                textAlign: TextAlign.center,
              ),
            ],
          ),
        ),
      ],
    );
  }
}

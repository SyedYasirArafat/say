import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../theme/app_theme.dart';
import '../providers/superweb_provider.dart';

// ===========================================================================
// TYPE F SCREEN - SAY INTELLECT (Education & Skills)
// ===========================================================================

class TypeFScreen extends StatelessWidget {
  const TypeFScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Consumer<SuperwebProvider>(
      builder: (context, provider, child) {
        final academic = provider.academicTranscript;
        
        return ListView(
          padding: const EdgeInsets.all(16),
          children: [
            // Section Header
            _buildSectionHeader(context, '📚 SAY Intellect', 'Learn • Evolve • Skill Up'),
            
            const SizedBox(height: 16),
            
            // Academic Profile
            _buildAcademicProfile(context, academic),
            
            const SizedBox(height: 24),
            
            // Skill Trees
            _buildSkillTrees(context, academic.skillTree, provider.isCrisisMode),
            
            const SizedBox(height: 24),
            
            // Active Courses
            _buildActiveCourses(context, academic.activeCourses, provider.isCrisisMode),
            
            const SizedBox(height: 24),
            
            // Job-Critical Alert (in crisis mode)
            if (provider.isCrisisMode)
              _buildJobCriticalAlert(context),
            
            const SizedBox(height: 100),
          ],
        );
      },
    );
  }

  Widget _buildSectionHeader(BuildContext context, String title, String subtitle) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(title, style: Theme.of(context).textTheme.headlineMedium),
        Text(subtitle, style: Theme.of(context).textTheme.bodySmall),
      ],
    );
  }

  Widget _buildAcademicProfile(BuildContext context, dynamic academic) {
    return Container(
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        gradient: LinearGradient(
          colors: [
            AppTheme.typeFColor.withOpacity(0.15),
            AppTheme.typeFColor.withOpacity(0.05),
          ],
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
        ),
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: AppTheme.typeFColor),
      ),
      child: Row(
        children: [
          Container(
            padding: const EdgeInsets.all(16),
            decoration: BoxDecoration(
              color: AppTheme.typeFColor.withOpacity(0.2),
              borderRadius: BorderRadius.circular(16),
            ),
            child: const Text('🎓', style: TextStyle(fontSize: 32)),
          ),
          const SizedBox(width: 16),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  academic.degree,
                  style: Theme.of(context).textTheme.titleMedium,
                ),
                const SizedBox(height: 4),
                Row(
                  children: [
                    const Icon(
                      Icons.school,
                      size: 14,
                      color: AppTheme.textMuted,
                    ),
                    const SizedBox(width: 4),
                    Text(
                      academic.almaMater,
                      style: Theme.of(context).textTheme.bodySmall,
                    ),
                  ],
                ),
              ],
            ),
          ),
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
            decoration: BoxDecoration(
              color: AppTheme.success.withOpacity(0.2),
              borderRadius: BorderRadius.circular(20),
            ),
            child: const Row(
              mainAxisSize: MainAxisSize.min,
              children: [
                Icon(Icons.verified, size: 14, color: AppTheme.success),
                SizedBox(width: 4),
                Text(
                  'Verified',
                  style: TextStyle(
                    fontSize: 11,
                    fontWeight: FontWeight.w600,
                    color: AppTheme.success,
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildSkillTrees(
    BuildContext context,
    Map<String, String> skillTree,
    bool isCrisisMode,
  ) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text('🌳 Skill Trees', style: Theme.of(context).textTheme.titleMedium),
        const SizedBox(height: 12),
        ...skillTree.entries.map((entry) {
          final levelMatch = RegExp(r'Level (\d+)').firstMatch(entry.value);
          final level = levelMatch != null ? int.parse(levelMatch.group(1)!) : 0;
          final isAI = entry.key.contains('AI');
          
          return Container(
            margin: const EdgeInsets.only(bottom: 12),
            padding: const EdgeInsets.all(16),
            decoration: BoxDecoration(
              color: (isAI && isCrisisMode) 
                  ? AppTheme.crisisRed.withOpacity(0.1)
                  : AppTheme.glassBg,
              borderRadius: BorderRadius.circular(16),
              border: Border.all(
                color: (isAI && isCrisisMode) 
                    ? AppTheme.crisisRed
                    : AppTheme.glassBorder,
                width: (isAI && isCrisisMode) ? 2 : 1,
              ),
            ),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  children: [
                    Text(
                      _getSkillIcon(entry.key),
                      style: const TextStyle(fontSize: 20),
                    ),
                    const SizedBox(width: 12),
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Row(
                            children: [
                              Text(
                                entry.key.replaceAll('_', ' '),
                                style: Theme.of(context).textTheme.titleSmall,
                              ),
                              if (isAI && isCrisisMode) ...[
                                const SizedBox(width: 8),
                                Container(
                                  padding: const EdgeInsets.symmetric(
                                    horizontal: 6,
                                    vertical: 2,
                                  ),
                                  decoration: BoxDecoration(
                                    color: AppTheme.crisisRed,
                                    borderRadius: BorderRadius.circular(4),
                                  ),
                                  child: const Text(
                                    'UPSKILL',
                                    style: TextStyle(
                                      fontSize: 8,
                                      fontWeight: FontWeight.w700,
                                      color: Colors.white,
                                    ),
                                  ),
                                ),
                              ],
                            ],
                          ),
                          Text(
                            entry.value,
                            style: Theme.of(context).textTheme.bodySmall,
                          ),
                        ],
                      ),
                    ),
                    Text(
                      'Lv.$level',
                      style: TextStyle(
                        fontSize: 16,
                        fontWeight: FontWeight.w800,
                        color: _getLevelColor(level),
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 12),
                ClipRRect(
                  borderRadius: BorderRadius.circular(6),
                  child: LinearProgressIndicator(
                    value: level / 10,
                    backgroundColor: AppTheme.bgTertiary,
                    valueColor: AlwaysStoppedAnimation(
                      (isAI && isCrisisMode) 
                          ? AppTheme.crisisRed
                          : _getLevelColor(level),
                    ),
                    minHeight: 8,
                  ),
                ),
              ],
            ),
          );
        }),
      ],
    );
  }

  Widget _buildActiveCourses(
    BuildContext context,
    List courses,
    bool isCrisisMode,
  ) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text('📖 Active Courses', style: Theme.of(context).textTheme.titleMedium),
        const SizedBox(height: 12),
        ...courses.map((course) {
          final isJobCritical = course.isJobCritical;
          
          return Container(
            margin: const EdgeInsets.only(bottom: 12),
            padding: const EdgeInsets.all(16),
            decoration: BoxDecoration(
              gradient: (isJobCritical && isCrisisMode)
                  ? LinearGradient(
                      colors: [
                        AppTheme.crisisRed.withOpacity(0.15),
                        Colors.transparent,
                      ],
                      begin: Alignment.topLeft,
                      end: Alignment.bottomRight,
                    )
                  : null,
              color: (isJobCritical && isCrisisMode) ? null : AppTheme.glassBg,
              borderRadius: BorderRadius.circular(16),
              border: Border.all(
                color: (isJobCritical && isCrisisMode)
                    ? AppTheme.crisisRed
                    : AppTheme.glassBorder,
                width: (isJobCritical && isCrisisMode) ? 2 : 1,
              ),
            ),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  children: [
                    Container(
                      padding: const EdgeInsets.all(10),
                      decoration: BoxDecoration(
                        color: AppTheme.typeFColor.withOpacity(0.2),
                        borderRadius: BorderRadius.circular(10),
                      ),
                      child: const Text('🎯', style: TextStyle(fontSize: 18)),
                    ),
                    const SizedBox(width: 12),
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            course.title,
                            style: Theme.of(context).textTheme.titleSmall,
                          ),
                          Text(
                            course.courseId,
                            style: Theme.of(context).textTheme.bodySmall,
                          ),
                        ],
                      ),
                    ),
                    if (isJobCritical)
                      Container(
                        padding: const EdgeInsets.symmetric(
                          horizontal: 8,
                          vertical: 4,
                        ),
                        decoration: BoxDecoration(
                          color: (isCrisisMode ? AppTheme.crisisRed : AppTheme.warning)
                              .withOpacity(0.2),
                          borderRadius: BorderRadius.circular(8),
                          border: Border.all(
                            color: isCrisisMode ? AppTheme.crisisRed : AppTheme.warning,
                          ),
                        ),
                        child: Text(
                          isCrisisMode ? '🔥 URGENT' : 'JOB CRITICAL',
                          style: TextStyle(
                            fontSize: 9,
                            fontWeight: FontWeight.w700,
                            color: isCrisisMode ? AppTheme.crisisRed : AppTheme.warning,
                          ),
                        ),
                      ),
                  ],
                ),
                const SizedBox(height: 16),
                Row(
                  children: [
                    Expanded(
                      child: ClipRRect(
                        borderRadius: BorderRadius.circular(6),
                        child: LinearProgressIndicator(
                          value: course.progress / 100,
                          backgroundColor: AppTheme.bgTertiary,
                          valueColor: AlwaysStoppedAnimation(
                            (isJobCritical && isCrisisMode) 
                                ? AppTheme.crisisRed
                                : AppTheme.typeFColor,
                          ),
                          minHeight: 10,
                        ),
                      ),
                    ),
                    const SizedBox(width: 12),
                    Text(
                      '${course.progress}%',
                      style: TextStyle(
                        fontSize: 14,
                        fontWeight: FontWeight.w700,
                        color: (isJobCritical && isCrisisMode) 
                            ? AppTheme.crisisRed
                            : AppTheme.typeFColor,
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 12),
                SizedBox(
                  width: double.infinity,
                  child: ElevatedButton(
                    onPressed: () {},
                    style: ElevatedButton.styleFrom(
                      backgroundColor: (isJobCritical && isCrisisMode)
                          ? AppTheme.crisisRed
                          : AppTheme.typeFColor,
                    ),
                    child: Text(isCrisisMode ? 'Resume Now →' : 'Continue Learning'),
                  ),
                ),
              ],
            ),
          );
        }),
      ],
    );
  }

  Widget _buildJobCriticalAlert(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        gradient: LinearGradient(
          colors: [
            AppTheme.crisisRed.withOpacity(0.2),
            AppTheme.crisisRed.withOpacity(0.05),
          ],
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
        ),
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: AppTheme.crisisRed, width: 2),
      ),
      child: Column(
        children: [
          const Text('🚨', style: TextStyle(fontSize: 32)),
          const SizedBox(height: 12),
          Text(
            'SAY-AI Recommendation',
            style: Theme.of(context).textTheme.titleMedium?.copyWith(
              color: AppTheme.crisisRed,
            ),
          ),
          const SizedBox(height: 8),
          Text(
            'Based on your financial situation, completing your AI courses will increase your employability by 40%',
            style: Theme.of(context).textTheme.bodyMedium,
            textAlign: TextAlign.center,
          ),
          const SizedBox(height: 16),
          Row(
            children: [
              Expanded(
                child: OutlinedButton(
                  onPressed: () {},
                  style: OutlinedButton.styleFrom(
                    foregroundColor: AppTheme.textMuted,
                    side: const BorderSide(color: AppTheme.glassBorder),
                  ),
                  child: const Text('Later'),
                ),
              ),
              const SizedBox(width: 12),
              Expanded(
                flex: 2,
                child: ElevatedButton(
                  onPressed: () {},
                  style: ElevatedButton.styleFrom(
                    backgroundColor: AppTheme.crisisRed,
                  ),
                  child: const Text('Start AI Course Now'),
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }

  String _getSkillIcon(String skill) {
    switch (skill.toLowerCase()) {
      case 'design':
        return '🎨';
      case 'project_mgmt':
        return '📋';
      case 'ai_tools':
        return '🤖';
      default:
        return '📚';
    }
  }

  Color _getLevelColor(int level) {
    if (level >= 7) return AppTheme.success;
    if (level >= 4) return AppTheme.warning;
    return AppTheme.typeFColor;
  }
}

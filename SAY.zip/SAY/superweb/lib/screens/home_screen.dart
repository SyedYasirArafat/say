import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../theme/app_theme.dart';
import '../providers/superweb_provider.dart';
import '../widgets/nav_bottom_bar.dart';
import '../widgets/ai_toast_overlay.dart';
import '../widgets/crisis_header.dart';
import 'type_a_screen.dart';
import 'type_b_screen.dart';
import 'type_c_screen.dart';
import 'type_d_screen.dart';
import 'type_f_screen.dart';
import 'type_e_screen.dart';
import '../widgets/z_gesture_detector.dart';

// ===========================================================================
// HOME SCREEN - SUPER-SHELL CONTAINER
// ===========================================================================

class HomeScreen extends StatelessWidget {
  const HomeScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Consumer<SuperwebProvider>(
      builder: (context, provider, child) {
        return Scaffold(
          backgroundColor: provider.isGhostMode ? AppTheme.ghostWhite : (provider.isCrisisMode 
              ? AppTheme.crisisBg 
              : AppTheme.bgPrimary),
          body: ZGestureDetector(
            onZGesture: () {
              // Trigger AI Governor / Ghost Mode Toggle
              provider.toggleGhostMode();
            },
            child: Stack(
            children: [
              // Background Gradient
              _buildBackgroundGradient(provider.isCrisisMode),
              
              // Main Content
              SafeArea(
                child: Column(
                  children: [
                    // App Header with SAY-ID
                    _buildHeader(context, provider),
                    
                    // Crisis Alert Banner (if active)
                    if (provider.isCrisisMode)
                      const CrisisHeader(),
                    
                    // Module Content
                    Expanded(
                      child: _buildModuleContent(provider.activeModule),
                    ),
                  ],
                ),
              ),
              
              // AI Toast Notifications
              const AIToastOverlay(),
            ],
          ),
          bottomNavigationBar: const NavBottomBar(),
        );
      },
    );
  }
  
  Widget _buildBackgroundGradient(bool isCrisisMode) {
    return Positioned.fill(
      child: DecoratedBox(
        decoration: BoxDecoration(
          gradient: RadialGradient(
            center: const Alignment(-0.8, -0.8),
            radius: 1.5,
            colors: isCrisisMode
                ? [
                    AppTheme.crisisRed.withOpacity(0.15),
                    Colors.transparent,
                  ]
                : [
                    AppTheme.accentPrimary.withOpacity(0.08),
                    Colors.transparent,
                  ],
          ),
        ),
      ),
    );
  }
  
  Widget _buildHeader(BuildContext context, SuperwebProvider provider) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 12),
      child: Row(
        children: [
          // Logo with Double-Tap Trigger
          GestureDetector(
            onDoubleTap: () {
              if (!provider.isCrisisMode) {
                provider.triggerSalaryMissingEvent();
              } else {
                provider.deactivateCrisisMode();
              }
            },
            child: Container(
              padding: const EdgeInsets.all(10),
              decoration: BoxDecoration(
                gradient: provider.isCrisisMode
                    ? AppTheme.crisisGradient
                    : AppTheme.accentGradient,
                borderRadius: BorderRadius.circular(12),
                boxShadow: [
                  BoxShadow(
                    color: (provider.isCrisisMode 
                        ? AppTheme.crisisRed 
                        : AppTheme.accentPrimary)
                        .withOpacity(0.4),
                    blurRadius: 20,
                    spreadRadius: 0,
                  ),
                ],
              ),
              child: const Text(
                '◈',
                style: TextStyle(
                  fontSize: 24,
                  color: Colors.white,
                ),
              ),
            ),
          ),
          
          const SizedBox(width: 12),
          
          // App Title
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  'SUPERWEB',
                  style: Theme.of(context).textTheme.titleMedium?.copyWith(
                    fontWeight: FontWeight.w800,
                    letterSpacing: 1,
                  ),
                ),
                Text(
                  provider.isGhostMode ? 'GHOST MODE' : (provider.isCrisisMode ? 'CRISIS MODE' : 'Digital Nation-State OS'),
                  style: Theme.of(context).textTheme.bodySmall?.copyWith(
                    color: provider.isGhostMode ? AppTheme.ghostText.withOpacity(0.6) : (provider.isCrisisMode 
                        ? AppTheme.crisisRed 
                        : AppTheme.textMuted),
                    letterSpacing: 0.5,
                  ),
                ),
              ],
            ),
          ),
          
          // User Badge
          _buildUserBadge(context, provider),
        ],
      ),
    );
  }
  
  Widget _buildUserBadge(BuildContext context, SuperwebProvider provider) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
      decoration: BoxDecoration(
        color: AppTheme.glassBg,
        borderRadius: BorderRadius.circular(20),
        border: Border.all(
          color: provider.isCrisisMode 
              ? AppTheme.crisisRed.withOpacity(0.5)
              : AppTheme.glassBorder,
        ),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          // Avatar
          Container(
            width: 32,
            height: 32,
            decoration: BoxDecoration(
              gradient: AppTheme.accentGradient,
              shape: BoxShape.circle,
            ),
            child: const Center(
              child: Text(
                'YA',
                style: TextStyle(
                  fontSize: 12,
                  fontWeight: FontWeight.w700,
                  color: Colors.black,
                ),
              ),
            ),
          ),
          const SizedBox(width: 8),
          Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            mainAxisSize: MainAxisSize.min,
            children: [
              Text(
                provider.userProfile.displayName,
                style: const TextStyle(
                  fontSize: 12,
                  fontWeight: FontWeight.w600,
                  color: AppTheme.textPrimary,
                ),
              ),
              Row(
                children: [
                  Container(
                    width: 6,
                    height: 6,
                    decoration: BoxDecoration(
                      color: provider.isCrisisMode 
                          ? AppTheme.crisisRed 
                          : AppTheme.success,
                      shape: BoxShape.circle,
                    ),
                  ),
                  const SizedBox(width: 4),
                  Text(
                    provider.isCrisisMode ? 'Alert' : 'Verified',
                    style: TextStyle(
                      fontSize: 10,
                      color: provider.isCrisisMode 
                          ? AppTheme.crisisRed 
                          : AppTheme.success,
                    ),
                  ),
                ],
              ),
            ],
          ),
        ],
      ),
    );
  }
  
  Widget _buildModuleContent(String module) {
    switch (module) {
      case 'a':
        return const TypeAScreen();
      case 'b':
        return const TypeBScreen();
      case 'c':
        return const TypeCScreen();
      case 'd':
        return const TypeDScreen();
      case 'f':
        return const TypeFScreen();
      case 'e':
        return const TypeEScreen();
      default:
        return const TypeAScreen();
    }
  }
}

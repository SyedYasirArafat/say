import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../theme/app_theme.dart';
import '../providers/superweb_provider.dart';

// ===========================================================================
// TYPE D SCREEN - JUSTICE OS (Legal & Fairness)
// ===========================================================================

class TypeDScreen extends StatelessWidget {
  const TypeDScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Consumer<SuperwebProvider>(
      builder: (context, provider, child) {
        final legal = provider.legalRecord;
        
        return ListView(
          padding: const EdgeInsets.all(16),
          children: [
            // Section Header
            _buildSectionHeader(context, '⚖️ Justice OS', 'Resolve • Protect • Predict'),
            
            const SizedBox(height: 16),
            
            // Record Status
            _buildRecordStatus(context, legal.status),
            
            const SizedBox(height: 24),
            
            // Active Cases
            if (legal.activeCases.isNotEmpty) ...[
              Text('📋 Active Cases', style: Theme.of(context).textTheme.titleMedium),
              const SizedBox(height: 12),
              ...legal.activeCases.map((c) => _buildCaseCard(context, c)),
            ],
            
            const SizedBox(height: 24),
            
            // AI Defense Brief
            if (legal.activeCases.isNotEmpty)
              _buildAIDefenseBrief(context, legal.activeCases.first),
            
            const SizedBox(height: 24),
            
            // Quick Resolve CTA
            _buildQuickResolveCTA(context),
            
            const SizedBox(height: 100),
          ],
        );
      },
    );
  }

  Widget _buildSectionHeader(BuildContext context, String title, String subtitle) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(title, style: Theme.of(context).textTheme.headlineMedium),
        Text(subtitle, style: Theme.of(context).textTheme.bodySmall),
      ],
    );
  }

  Widget _buildRecordStatus(BuildContext context, String status) {
    final isClean = status == 'CLEAN';
    
    return Container(
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        gradient: LinearGradient(
          colors: [
            (isClean ? AppTheme.success : AppTheme.warning).withOpacity(0.15),
            Colors.transparent,
          ],
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
        ),
        borderRadius: BorderRadius.circular(20),
        border: Border.all(
          color: isClean ? AppTheme.success : AppTheme.warning,
        ),
      ),
      child: Row(
        children: [
          Container(
            padding: const EdgeInsets.all(12),
            decoration: BoxDecoration(
              color: (isClean ? AppTheme.success : AppTheme.warning).withOpacity(0.2),
              borderRadius: BorderRadius.circular(12),
            ),
            child: Text(
              isClean ? '✅' : '⚠️',
              style: const TextStyle(fontSize: 28),
            ),
          ),
          const SizedBox(width: 16),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  'Legal Record',
                  style: Theme.of(context).textTheme.bodySmall,
                ),
                const SizedBox(height: 4),
                Text(
                  status.replaceAll('_', ' '),
                  style: Theme.of(context).textTheme.headlineMedium?.copyWith(
                    color: isClean ? AppTheme.success : AppTheme.warning,
                    fontWeight: FontWeight.w800,
                  ),
                ),
              ],
            ),
          ),
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
            decoration: BoxDecoration(
              color: isClean ? AppTheme.success : AppTheme.warning,
              borderRadius: BorderRadius.circular(20),
            ),
            child: Text(
              isClean ? 'No Convictions' : 'Pending',
              style: const TextStyle(
                fontSize: 11,
                fontWeight: FontWeight.w700,
                color: Colors.white,
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildCaseCard(BuildContext context, dynamic caseData) {
    final winProb = caseData.aiAnalysis.probabilityOfWin;
    final probColor = winProb >= 70 
        ? AppTheme.success 
        : winProb >= 50 
            ? AppTheme.warning 
            : AppTheme.error;

    return Container(
      margin: const EdgeInsets.only(bottom: 12),
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: AppTheme.glassBg,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: AppTheme.glassBorder),
        boxShadow: [
          BoxShadow(
            color: AppTheme.typeDColor.withOpacity(0.1),
            blurRadius: 20,
            spreadRadius: 0,
          ),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // Header
          Row(
            children: [
              Text(
                caseData.caseId,
                style: TextStyle(
                  fontFamily: 'monospace',
                  fontSize: 11,
                  color: AppTheme.textMuted,
                ),
              ),
              const Spacer(),
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                decoration: BoxDecoration(
                  color: AppTheme.typeDColor,
                  borderRadius: BorderRadius.circular(12),
                ),
                child: Text(
                  caseData.type.replaceAll('_', ' '),
                  style: const TextStyle(
                    fontSize: 9,
                    fontWeight: FontWeight.w700,
                    color: Colors.white,
                  ),
                ),
              ),
            ],
          ),
          
          const SizedBox(height: 12),
          
          // Description
          Text(
            caseData.description,
            style: Theme.of(context).textTheme.titleSmall,
          ),
          
          const SizedBox(height: 8),
          
          // Details row
          Row(
            children: [
              Text(
                '📅 ${_formatDate(caseData.issuedAt)}',
                style: Theme.of(context).textTheme.bodySmall,
              ),
              const SizedBox(width: 16),
              Text(
                '💰 ₹${caseData.fineAmount.toInt()}',
                style: Theme.of(context).textTheme.bodySmall,
              ),
            ],
          ),
          
          const SizedBox(height: 16),
          
          // Win probability gauge
          Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                children: [
                  const Text(
                    '🔮 Win Probability',
                    style: TextStyle(fontSize: 12, color: AppTheme.textMuted),
                  ),
                  const Spacer(),
                  Text(
                    '${winProb.toStringAsFixed(1)}%',
                    style: TextStyle(
                      fontSize: 18,
                      fontWeight: FontWeight.w800,
                      color: probColor,
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 8),
              ClipRRect(
                borderRadius: BorderRadius.circular(6),
                child: LinearProgressIndicator(
                  value: winProb / 100,
                  backgroundColor: AppTheme.bgTertiary,
                  valueColor: AlwaysStoppedAnimation(probColor),
                  minHeight: 10,
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }

  Widget _buildAIDefenseBrief(BuildContext context, dynamic caseData) {
    final analysis = caseData.aiAnalysis;
    
    return Container(
      padding: const EdgeInsets.all(20),
      decoration: AppTheme.glassDecorationWithGlow(AppTheme.typeDColor),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Container(
                padding: const EdgeInsets.all(8),
                decoration: BoxDecoration(
                  color: AppTheme.typeDColor.withOpacity(0.2),
                  borderRadius: BorderRadius.circular(8),
                ),
                child: const Text('🤖', style: TextStyle(fontSize: 20)),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      'AI Defense Brief',
                      style: Theme.of(context).textTheme.titleMedium?.copyWith(
                        color: AppTheme.typeDColor,
                      ),
                    ),
                    const Text(
                      'Auto-generated legal strategy',
                      style: TextStyle(fontSize: 11, color: AppTheme.textMuted),
                    ),
                  ],
                ),
              ),
            ],
          ),
          
          const SizedBox(height: 20),
          
          _buildBriefItem(
            '🎯',
            'Defense Strategy',
            analysis.defenseStrategy.replaceAll('_', ' '),
          ),
          
          const Divider(height: 24, color: AppTheme.glassBorder),
          
          _buildBriefItem(
            '⚡',
            'Action Taken',
            analysis.actionTaken.replaceAll('_', ' '),
          ),
          
          const SizedBox(height: 16),
          
          SizedBox(
            width: double.infinity,
            child: OutlinedButton.icon(
              onPressed: () {},
              icon: const Icon(Icons.gavel, size: 18),
              label: const Text('View Full Brief'),
              style: OutlinedButton.styleFrom(
                foregroundColor: AppTheme.typeDColor,
                side: const BorderSide(color: AppTheme.typeDColor),
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildBriefItem(String icon, String label, String value) {
    return Row(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(icon, style: const TextStyle(fontSize: 16)),
        const SizedBox(width: 12),
        Expanded(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                label,
                style: const TextStyle(fontSize: 11, color: AppTheme.textMuted),
              ),
              const SizedBox(height: 2),
              Text(
                value,
                style: const TextStyle(
                  fontSize: 14,
                  fontWeight: FontWeight.w600,
                  color: AppTheme.textPrimary,
                ),
              ),
            ],
          ),
        ),
      ],
    );
  }

  Widget _buildQuickResolveCTA(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        gradient: LinearGradient(
          colors: [
            AppTheme.typeDColor.withOpacity(0.15),
            AppTheme.typeDColor.withOpacity(0.05),
          ],
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
        ),
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: AppTheme.typeDColor),
      ),
      child: Column(
        children: [
          const Text('💬', style: TextStyle(fontSize: 32)),
          const SizedBox(height: 12),
          Text(
            'Online Dispute Resolution',
            style: Theme.of(context).textTheme.titleMedium,
            textAlign: TextAlign.center,
          ),
          const SizedBox(height: 4),
          Text(
            'Settle disputes without court in under 15 minutes',
            style: Theme.of(context).textTheme.bodySmall,
            textAlign: TextAlign.center,
          ),
          const SizedBox(height: 16),
          SizedBox(
            width: double.infinity,
            child: ElevatedButton(
              onPressed: () {},
              style: ElevatedButton.styleFrom(
                backgroundColor: AppTheme.typeDColor,
              ),
              child: const Text('Start ODR Session →'),
            ),
          ),
        ],
      ),
    );
  }

  String _formatDate(DateTime date) {
    return '${date.day}/${date.month}/${date.year}';
  }
}

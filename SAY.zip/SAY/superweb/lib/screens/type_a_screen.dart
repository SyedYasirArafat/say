import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../theme/app_theme.dart';
import '../providers/superweb_provider.dart';

// ===========================================================================
// TYPE A SCREEN - FLIMXGO (Lifestyle & Consumption)
// ===========================================================================

class TypeAScreen extends StatelessWidget {
  const TypeAScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Consumer<SuperwebProvider>(
      builder: (context, provider, child) {
        final prefs = provider.lifestylePrefs;
        final streaming = prefs.streamingProfile;
        
        return ListView(
          padding: const EdgeInsets.all(16),
          children: [
            // Section Header
            _buildSectionHeader(context, '📺 FlimXgo', 'Stream • Shop • Connect'),
            
            const SizedBox(height: 16),
            
            // Time Pass Balance
            _buildTimePassCard(context, streaming, provider.isCrisisMode),
            
            const SizedBox(height: 24),
            
            // Currently Watching
            _buildCurrentlyWatching(context, streaming),
            
            const SizedBox(height: 24),
            
            // Recommendations
            _buildRecommendations(context, streaming.recommendations),
            
            const SizedBox(height: 24),
            
            // Recent Calls
            _buildRecentCalls(context, prefs.social),
            
            const SizedBox(height: 100), // Bottom padding for nav
          ],
        );
      },
    );
  }

  Widget _buildSectionHeader(BuildContext context, String title, String subtitle) {
    return Row(
      children: [
        Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              title,
              style: Theme.of(context).textTheme.headlineMedium,
            ),
            Text(
              subtitle,
              style: Theme.of(context).textTheme.bodySmall,
            ),
          ],
        ),
      ],
    );
  }

  Widget _buildTimePassCard(
    BuildContext context,
    dynamic streaming,
    bool isCrisisMode,
  ) {
    return Container(
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        gradient: LinearGradient(
          colors: isCrisisMode
              ? [
                  AppTheme.crisisRed.withOpacity(0.2),
                  AppTheme.crisisRed.withOpacity(0.1),
                ]
              : [
                  AppTheme.typeAColor.withOpacity(0.2),
                  AppTheme.typeAColor.withOpacity(0.05),
                ],
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
        ),
        borderRadius: BorderRadius.circular(20),
        border: Border.all(
          color: isCrisisMode ? AppTheme.crisisRed : AppTheme.typeAColor,
        ),
      ),
      child: Row(
        children: [
          Container(
            padding: const EdgeInsets.all(12),
            decoration: BoxDecoration(
              color: Colors.white.withOpacity(0.1),
              borderRadius: BorderRadius.circular(12),
            ),
            child: const Text('⏱️', style: TextStyle(fontSize: 28)),
          ),
          const SizedBox(width: 16),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  'Time Pass Balance',
                  style: Theme.of(context).textTheme.bodySmall,
                ),
                const SizedBox(height: 4),
                Text(
                  streaming.watchTimeBalance,
                  style: Theme.of(context).textTheme.headlineMedium?.copyWith(
                    color: isCrisisMode ? AppTheme.crisisRed : AppTheme.typeAColor,
                    fontWeight: FontWeight.w800,
                  ),
                ),
              ],
            ),
          ),
          if (!isCrisisMode)
            ElevatedButton(
              onPressed: () {},
              style: ElevatedButton.styleFrom(
                backgroundColor: AppTheme.typeAColor,
              ),
              child: const Text('Top Up'),
            )
          else
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
              decoration: BoxDecoration(
                color: AppTheme.crisisRed.withOpacity(0.2),
                borderRadius: BorderRadius.circular(8),
                border: Border.all(color: AppTheme.crisisRed),
              ),
              child: const Text(
                'PAUSED',
                style: TextStyle(
                  fontSize: 12,
                  fontWeight: FontWeight.w700,
                  color: AppTheme.crisisRed,
                ),
              ),
            ),
        ],
      ),
    );
  }

  Widget _buildCurrentlyWatching(BuildContext context, dynamic streaming) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          '▶️ Continue Watching',
          style: Theme.of(context).textTheme.titleMedium,
        ),
        const SizedBox(height: 12),
        Container(
          padding: const EdgeInsets.all(16),
          decoration: AppTheme.glassDecoration,
          child: Row(
            children: [
              Container(
                width: 80,
                height: 60,
                decoration: BoxDecoration(
                  color: AppTheme.bgTertiary,
                  borderRadius: BorderRadius.circular(8),
                ),
                child: const Center(
                  child: Text('🎬', style: TextStyle(fontSize: 24)),
                ),
              ),
              const SizedBox(width: 16),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      streaming.currentBinge,
                      style: Theme.of(context).textTheme.titleSmall,
                    ),
                    const SizedBox(height: 4),
                    Row(
                      children: [
                        Expanded(
                          child: ClipRRect(
                            borderRadius: BorderRadius.circular(4),
                            child: LinearProgressIndicator(
                              value: 0.67,
                              backgroundColor: AppTheme.bgTertiary,
                              valueColor: AlwaysStoppedAnimation(AppTheme.typeAColor),
                            ),
                          ),
                        ),
                        const SizedBox(width: 8),
                        Text(
                          'S3 E7',
                          style: Theme.of(context).textTheme.bodySmall,
                        ),
                      ],
                    ),
                  ],
                ),
              ),
              const SizedBox(width: 12),
              Container(
                width: 48,
                height: 48,
                decoration: BoxDecoration(
                  color: AppTheme.typeAColor,
                  shape: BoxShape.circle,
                ),
                child: const Icon(
                  Icons.play_arrow,
                  color: Colors.white,
                ),
              ),
            ],
          ),
        ),
      ],
    );
  }

  Widget _buildRecommendations(BuildContext context, List recommendations) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          '🔥 For You',
          style: Theme.of(context).textTheme.titleMedium,
        ),
        const SizedBox(height: 12),
        SizedBox(
          height: 180,
          child: ListView.separated(
            scrollDirection: Axis.horizontal,
            itemCount: recommendations.length,
            separatorBuilder: (_, __) => const SizedBox(width: 12),
            itemBuilder: (context, index) {
              final rec = recommendations[index];
              return Container(
                width: 140,
                decoration: AppTheme.glassDecoration,
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Container(
                      height: 100,
                      decoration: BoxDecoration(
                        color: AppTheme.bgTertiary,
                        borderRadius: const BorderRadius.vertical(
                          top: Radius.circular(16),
                        ),
                      ),
                      child: const Center(
                        child: Text('🎥', style: TextStyle(fontSize: 32)),
                      ),
                    ),
                    Padding(
                      padding: const EdgeInsets.all(12),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            rec.title,
                            style: Theme.of(context).textTheme.titleSmall,
                            maxLines: 1,
                            overflow: TextOverflow.ellipsis,
                          ),
                          const SizedBox(height: 4),
                          Row(
                            children: [
                              Text(
                                rec.genre,
                                style: Theme.of(context).textTheme.bodySmall,
                              ),
                              const Spacer(),
                              Text(
                                rec.match,
                                style: TextStyle(
                                  fontSize: 12,
                                  fontWeight: FontWeight.w600,
                                  color: AppTheme.success,
                                ),
                              ),
                            ],
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
              );
            },
          ),
        ),
      ],
    );
  }

  Widget _buildRecentCalls(BuildContext context, dynamic social) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Row(
          children: [
            Text(
              '📞 Recent Calls',
              style: Theme.of(context).textTheme.titleMedium,
            ),
            const Spacer(),
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
              decoration: BoxDecoration(
                color: AppTheme.success.withOpacity(0.2),
                borderRadius: BorderRadius.circular(12),
              ),
              child: Row(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Container(
                    width: 6,
                    height: 6,
                    decoration: const BoxDecoration(
                      color: AppTheme.success,
                      shape: BoxShape.circle,
                    ),
                  ),
                  const SizedBox(width: 4),
                  Text(
                    social.status,
                    style: const TextStyle(
                      fontSize: 10,
                      color: AppTheme.success,
                      fontWeight: FontWeight.w600,
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
        const SizedBox(height: 12),
        ...social.recentCalls.map<Widget>((call) {
          return Container(
            margin: const EdgeInsets.only(bottom: 8),
            padding: const EdgeInsets.all(12),
            decoration: AppTheme.glassDecoration,
            child: Row(
              children: [
                Container(
                  width: 44,
                  height: 44,
                  decoration: BoxDecoration(
                    color: AppTheme.bgTertiary,
                    shape: BoxShape.circle,
                  ),
                  child: Center(
                    child: Text(
                      call.name[0],
                      style: const TextStyle(
                        fontSize: 18,
                        fontWeight: FontWeight.w600,
                      ),
                    ),
                  ),
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        call.name,
                        style: Theme.of(context).textTheme.titleSmall,
                      ),
                      Row(
                        children: [
                          _getCallTypeIcon(call.type),
                          const SizedBox(width: 4),
                          Text(
                            '${call.type.replaceAll('_', ' ')} • ${call.duration}',
                            style: Theme.of(context).textTheme.bodySmall,
                          ),
                        ],
                      ),
                    ],
                  ),
                ),
                IconButton(
                  onPressed: () {},
                  icon: Icon(
                    Icons.call,
                    color: AppTheme.typeAColor,
                  ),
                ),
              ],
            ),
          );
        }).toList(),
      ],
    );
  }

  Widget _getCallTypeIcon(String type) {
    switch (type) {
      case 'HOLO_3D':
        return const Text('🌀', style: TextStyle(fontSize: 14));
      case 'VIDEO':
        return const Text('📹', style: TextStyle(fontSize: 14));
      default:
        return const Text('📞', style: TextStyle(fontSize: 14));
    }
  }
}

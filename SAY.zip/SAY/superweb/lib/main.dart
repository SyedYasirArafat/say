import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import 'theme/app_theme.dart';
import 'providers/superweb_provider.dart';
import 'screens/home_screen.dart';

// ===========================================================================
// SUPERWEB - DIGITAL NATION-STATE OS
// Entry Point
// ===========================================================================

void main() {
  WidgetsFlutterBinding.ensureInitialized();
  
  runApp(
    MultiProvider(
      providers: [
        ChangeNotifierProvider(create: (_) => SuperwebProvider()),
      ],
      child: const SuperwebApp(),
    ),
  );
}

class SuperwebApp extends StatelessWidget {
  const SuperwebApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Superweb',
      debugShowCheckedModeBanner: false,
      theme: AppTheme.darkTheme,
      home: const HomeScreen(),
    );
  }
}

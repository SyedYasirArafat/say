import 'package:flutter/foundation.dart';
import '../data/mock_data.dart';

// ===========================================================================
// SUPERWEB STATE PROVIDER
// Manages app state, crisis mode, and cross-module orchestration
// ===========================================================================

class SuperwebProvider extends ChangeNotifier {
  // ========== STATE ==========
  
  // Current active module
  String _activeModule = 'a'; // a, b, c, d, f
  String get activeModule => _activeModule;
  
  // Crisis Mode
  bool _isCrisisMode = false;
  bool get isCrisisMode => _isCrisisMode;
  
  // Current system event (if any)
  SystemEvent? _currentEvent;
  SystemEvent? get currentEvent => _currentEvent;
  
  // Toast message queue
  final List<String> _toastQueue = [];
  List<String> get toastQueue => _toastQueue;
  
  // Subscription states (for pause/resume during crisis)
  late List<Subscription> _subscriptions;
  List<Subscription> get subscriptions => _subscriptions;
  
  // ========== CONSTRUCTOR ==========
  
  SuperwebProvider() {
    // Initialize with mock data
    _subscriptions = List.from(MockData.financePortfolio.subscriptions);
  }
  
  // ========== NEW V2 STATE ==========
  
  // Ghost Mode (Privacy)
  bool _isGhostMode = false;
  bool get isGhostMode => _isGhostMode;

  // Panic Mode (Health/Safety)
  bool _isPanicMode = false;
  bool get isPanicMode => _isPanicMode;

  // ========== DATA GETTERS ==========
  
  UserProfile get userProfile => MockData.userProfile;
  FinancePortfolio get financePortfolio => MockData.financePortfolio;
  LifestylePrefs get lifestylePrefs => MockData.lifestylePrefs;
  LegalRecord get legalRecord => MockData.legalRecord;
  AcademicTranscript get academicTranscript => MockData.academicTranscript;
  HealthRecord get healthRecord => MockData.healthRecord; // Type E
  
  // ========== NAVIGATION ==========
  
  void switchModule(String module) {
    if (_activeModule != module) {
      _activeModule = module;
      notifyListeners();
    }
  }
  
  // ========== V2 FEATURES ==========

  void toggleGhostMode() {
    _isGhostMode = !_isGhostMode;
    if (_isGhostMode) {
      addToast("👻 Ghost Mode Activated: Location tracking disabled");
      addToast("🔒 Type A & C Disconnected");
    } else {
      addToast("🔵 Ghost Mode Deactivated: Services restored");
    }
    notifyListeners();
  }

  void triggerPanicMode() {
    _isPanicMode = true;
    _activeModule = 'e'; // Switch to Health/Emergency
    
    addToast("🚨 PANIC MODE ACTIVATED");
    
    Future.delayed(const Duration(milliseconds: 1000), () {
      addToast("🚓 GPS Sent to Police Control Room");
    });
    
    Future.delayed(const Duration(milliseconds: 2000), () {
      addToast("🏥 Medical ID Flashing on Lock Screen");
    });

    Future.delayed(const Duration(milliseconds: 3000), () {
      addToast("💸 ₹50,000 Emergency Fund Unlocked (Type B)");
    });
    
    notifyListeners();
  }

  void resetPanicMode() {
    _isPanicMode = false;
    notifyListeners();
  }
  
  // ========== CRISIS MODE ==========
  
  /// Trigger the salary missing crisis event
  /// This is called when user double-taps the logo
  void triggerSalaryMissingEvent() {
    _currentEvent = MockData.salaryMissingEvent;
    _activateCrisisMode();
    notifyListeners();
  }
  
  void _activateCrisisMode() {
    _isCrisisMode = true;
    
    // Execute suggested actions
    for (final action in _currentEvent!.payload.suggestedActions) {
      _executeAction(action);
    }
    
    // Show AI Governor notification
    addToast("🚨 SAY-AI Governor: ${_currentEvent!.payload.message}");
    
    // Cascade notifications
    Future.delayed(const Duration(milliseconds: 1500), () {
      addToast("💰 Type B: Activating Austerity Mode...");
    });
    
    Future.delayed(const Duration(milliseconds: 3000), () {
      addToast("📺 Type A: Pausing premium subscriptions to save ₹3,698/month");
    });
    
    Future.delayed(const Duration(milliseconds: 4500), () {
      addToast("💼 Type B: Opening Gig-Hub for emergency income options");
    });
    
    Future.delayed(const Duration(milliseconds: 6000), () {
      addToast("📚 Type F: Highlighting job-critical courses");
    });
  }
  
  void _executeAction(String action) {
    switch (action) {
      case 'ACTIVATE_AUSTERITY_MODE':
        // Already handled by crisis mode
        break;
        
      case 'PAUSE_SUBSCRIPTIONS':
        _pauseNonEssentialSubscriptions();
        break;
        
      case 'OPEN_GIG_HUB':
        // Navigate to Type B Gig-Hub section
        Future.delayed(const Duration(seconds: 7), () {
          switchModule('b');
        });
        break;
    }
  }
  
  void _pauseNonEssentialSubscriptions() {
    _subscriptions = _subscriptions.map((sub) {
      if (sub.name != 'SAY Citizen') {
        return Subscription(
          name: sub.name,
          cost: sub.cost,
          status: 'PAUSED',
        );
      }
      return sub;
    }).toList();
    notifyListeners();
  }
  
  void deactivateCrisisMode() {
    _isCrisisMode = false;
    _currentEvent = null;
    
    // Restore subscriptions
    _subscriptions = List.from(MockData.financePortfolio.subscriptions);
    
    notifyListeners();
  }
  
  // ========== TOAST NOTIFICATIONS ==========
  
  void addToast(String message) {
    _toastQueue.add(message);
    notifyListeners();
    
    // Auto-remove after 4 seconds
    Future.delayed(const Duration(seconds: 4), () {
      if (_toastQueue.isNotEmpty) {
        _toastQueue.removeAt(0);
        notifyListeners();
      }
    });
  }
  
  void clearToast(int index) {
    if (index < _toastQueue.length) {
      _toastQueue.removeAt(index);
      notifyListeners();
    }
  }
  
  // ========== COMPUTED PROPERTIES ==========
  
  double get totalSubscriptionCost => 
      _subscriptions.fold(0, (sum, sub) => sum + sub.cost);
  
  double get pausedSubscriptionSavings => 
      _subscriptions
          .where((s) => s.status == 'PAUSED')
          .fold(0, (sum, sub) => sum + sub.cost);
  
  double get portfolioValue =>
      financePortfolio.holdings.fold(0, (sum, h) => sum + h.currentValue);
  
  double get runwayMonths => 
      financePortfolio.currentBalance / financePortfolio.monthlyBurnRate;
  
  String get runwayStatus {
    if (runwayMonths > 6) return 'HEALTHY';
    if (runwayMonths > 3) return 'MODERATE';
    return 'CRITICAL';
  }
}

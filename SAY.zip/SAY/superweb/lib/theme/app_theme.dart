import 'package:flutter/material.dart';

// ===========================================================================
// SUPERWEB APP THEME
// Premium Dark Theme with Glassmorphism & Type-Specific Accents
// ===========================================================================

class AppTheme {
  // ========== COLORS ==========
  
  // Base Colors
  static const Color bgPrimary = Color(0xFF0A0A0F);
  static const Color bgSecondary = Color(0xFF12121A);
  static const Color bgTertiary = Color(0xFF1A1A25);
  static const Color bgElevated = Color(0xFF222230);
  
  // Glass Effect
  static const Color glassBg = Color(0x08FFFFFF);
  static const Color glassBorder = Color(0x14FFFFFF);
  static const Color glassHover = Color(0x0FFFFFFF);
  
  // Text Colors
  static const Color textPrimary = Color(0xFFFFFFFF);
  static const Color textSecondary = Color(0xFFA0A0B0);
  static const Color textMuted = Color(0xFF606070);
  
  // Brand Accent (Gold/Amber)
  static const Color accentPrimary = Color(0xFFF59E0B);
  static const Color accentSecondary = Color(0xFFFBBF24);
  
  // Type-Specific Colors
  static const Color typeAColor = Color(0xFFEC4899);  // FlimXgo - Pink
  static const Color typeBColor = Color(0xFF10B981);  // Finance - Emerald
  static const Color typeCColor = Color(0xFF3B82F6);  // GovConnect - Blue
  static const Color typeDColor = Color(0xFF8B5CF6);  // Justice - Purple
  static const Color typeFColor = Color(0xFF06B6D4);  // Intellect - Cyan
  static const Color typeEColor = Color(0xFFEF4444);  // Health - Red
  
  // Semantic Colors
  static const Color success = Color(0xFF22C55E);
  static const Color warning = Color(0xFFF59E0B);
  static const Color error = Color(0xFFEF4444);
  static const Color info = Color(0xFF3B82F6);
  
  // Crisis Mode Colors
  static const Color crisisRed = Color(0xFFDC2626);
  static const Color crisisBg = Color(0xFF1A0A0A);

  // Ghost Mode Colors
  static const Color ghostWhite = Color(0xFFF8FAFC);
  static const Color ghostText = Color(0xFF0F172A);
  static const Color ghostAccent = Color(0xFF94A3B8);

  // Gradient Helpers for Type E Screen
  static LinearGradient get glassGradient => LinearGradient(
    colors: [
      Colors.white.withOpacity(0.1),
      Colors.white.withOpacity(0.05),
    ],
    begin: Alignment.topLeft,
    end: Alignment.bottomRight,
  );

  static LinearGradient get borderGradient => LinearGradient(
    colors: [
      Colors.white.withOpacity(0.5),
      Colors.white.withOpacity(0.1),
    ],
    begin: Alignment.topLeft,
    end: Alignment.bottomRight,
  );
  
  static TextStyle get h3 => const TextStyle(
    fontSize: 18,
    fontWeight: FontWeight.w700,
    color: textPrimary,
  );
  
  // ========== THEME DATA ==========
  
  static ThemeData get darkTheme => ThemeData(
    useMaterial3: true,
    brightness: Brightness.dark,
    scaffoldBackgroundColor: bgPrimary,
    primaryColor: accentPrimary,
    colorScheme: const ColorScheme.dark(
      primary: accentPrimary,
      secondary: accentSecondary,
      surface: bgSecondary,
      error: error,
    ),
    fontFamily: 'Inter',
    
    // App Bar
    appBarTheme: const AppBarTheme(
      backgroundColor: Colors.transparent,
      elevation: 0,
      centerTitle: false,
      titleTextStyle: TextStyle(
        fontFamily: 'Inter',
        fontSize: 20,
        fontWeight: FontWeight.w700,
        color: textPrimary,
      ),
      iconTheme: IconThemeData(color: textPrimary),
    ),
    
    // Cards
    cardTheme: CardThemeData(
      color: glassBg,
      elevation: 0,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(16),
        side: const BorderSide(color: glassBorder),
      ),
    ),
    
    // Elevated Buttons
    elevatedButtonTheme: ElevatedButtonThemeData(
      style: ElevatedButton.styleFrom(
        backgroundColor: accentPrimary,
        foregroundColor: bgPrimary,
        elevation: 0,
        padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 14),
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(12),
        ),
        textStyle: const TextStyle(
          fontFamily: 'Inter',
          fontSize: 14,
          fontWeight: FontWeight.w600,
        ),
      ),
    ),
    
    // Outlined Buttons
    outlinedButtonTheme: OutlinedButtonThemeData(
      style: OutlinedButton.styleFrom(
        foregroundColor: accentPrimary,
        side: const BorderSide(color: accentPrimary),
        padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 14),
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(12),
        ),
        textStyle: const TextStyle(
          fontFamily: 'Inter',
          fontSize: 14,
          fontWeight: FontWeight.w600,
        ),
      ),
    ),
    
    // Text Buttons
    textButtonTheme: TextButtonThemeData(
      style: TextButton.styleFrom(
        foregroundColor: accentPrimary,
        textStyle: const TextStyle(
          fontFamily: 'Inter',
          fontSize: 14,
          fontWeight: FontWeight.w600,
        ),
      ),
    ),
    
    // Input Decoration
    inputDecorationTheme: InputDecorationTheme(
      filled: true,
      fillColor: bgTertiary,
      border: OutlineInputBorder(
        borderRadius: BorderRadius.circular(12),
        borderSide: const BorderSide(color: glassBorder),
      ),
      enabledBorder: OutlineInputBorder(
        borderRadius: BorderRadius.circular(12),
        borderSide: const BorderSide(color: glassBorder),
      ),
      focusedBorder: OutlineInputBorder(
        borderRadius: BorderRadius.circular(12),
        borderSide: const BorderSide(color: accentPrimary, width: 2),
      ),
      hintStyle: const TextStyle(color: textMuted),
      contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
    ),
    
    // Bottom Navigation
    bottomNavigationBarTheme: const BottomNavigationBarThemeData(
      backgroundColor: bgSecondary,
      selectedItemColor: accentPrimary,
      unselectedItemColor: textMuted,
      type: BottomNavigationBarType.fixed,
      elevation: 0,
    ),
    
    // Divider
    dividerTheme: const DividerThemeData(
      color: glassBorder,
      thickness: 1,
    ),
    
    // Text Theme
    textTheme: const TextTheme(
      displayLarge: TextStyle(
        fontSize: 32,
        fontWeight: FontWeight.w800,
        color: textPrimary,
        letterSpacing: -0.5,
      ),
      displayMedium: TextStyle(
        fontSize: 28,
        fontWeight: FontWeight.w700,
        color: textPrimary,
      ),
      displaySmall: TextStyle(
        fontSize: 24,
        fontWeight: FontWeight.w700,
        color: textPrimary,
      ),
      headlineMedium: TextStyle(
        fontSize: 20,
        fontWeight: FontWeight.w600,
        color: textPrimary,
      ),
      titleLarge: TextStyle(
        fontSize: 18,
        fontWeight: FontWeight.w600,
        color: textPrimary,
      ),
      titleMedium: TextStyle(
        fontSize: 16,
        fontWeight: FontWeight.w600,
        color: textPrimary,
      ),
      titleSmall: TextStyle(
        fontSize: 14,
        fontWeight: FontWeight.w600,
        color: textPrimary,
      ),
      bodyLarge: TextStyle(
        fontSize: 16,
        fontWeight: FontWeight.w400,
        color: textSecondary,
      ),
      bodyMedium: TextStyle(
        fontSize: 14,
        fontWeight: FontWeight.w400,
        color: textSecondary,
      ),
      bodySmall: TextStyle(
        fontSize: 12,
        fontWeight: FontWeight.w400,
        color: textMuted,
      ),
      labelLarge: TextStyle(
        fontSize: 14,
        fontWeight: FontWeight.w600,
        color: textPrimary,
      ),
      labelSmall: TextStyle(
        fontSize: 10,
        fontWeight: FontWeight.w500,
        color: textMuted,
        letterSpacing: 1.5,
      ),
    ),
  );
  
  // ========== HELPER METHODS ==========
  
  static Color getTypeColor(String type) {
    switch (type.toLowerCase()) {
      case 'a':
        return typeAColor;
      case 'b':
        return typeBColor;
      case 'c':
        return typeCColor;
      case 'd':
        return typeDColor;
      case 'f':
        return typeFColor;
      default:
        return accentPrimary;
    }
  }
  
  static LinearGradient get accentGradient => const LinearGradient(
    colors: [accentPrimary, accentSecondary],
    begin: Alignment.topLeft,
    end: Alignment.bottomRight,
  );
  
  static LinearGradient crisisGradient = const LinearGradient(
    colors: [crisisRed, Color(0xFFB91C1C)],
    begin: Alignment.topLeft,
    end: Alignment.bottomRight,
  );
  
  static BoxDecoration get glassDecoration => BoxDecoration(
    color: glassBg,
    borderRadius: BorderRadius.circular(16),
    border: Border.all(color: glassBorder),
  );
  
  static BoxDecoration glassDecorationWithGlow(Color glowColor) => BoxDecoration(
    color: glassBg,
    borderRadius: BorderRadius.circular(16),
    border: Border.all(color: glowColor.withOpacity(0.5)),
    boxShadow: [
      BoxShadow(
        color: glowColor.withOpacity(0.2),
        blurRadius: 20,
        spreadRadius: 0,
      ),
    ],
  );
}

// ========== SPACING CONSTANTS ==========
class AppSpacing {
  static const double xs = 4;
  static const double sm = 8;
  static const double md = 16;
  static const double lg = 24;
  static const double xl = 32;
  static const double xxl = 48;
}

// ========== BORDER RADIUS CONSTANTS ==========
class AppRadius {
  static const double sm = 6;
  static const double md = 12;
  static const double lg = 16;
  static const double xl = 24;
  static const double full = 9999;
}

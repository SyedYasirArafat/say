// ===========================================================================
// SUPERWEB MOCK DATA
// Persona: Syed Yasir Arafat - Senior Systems Architect
// Location: HSR Layout, Sector 4, Bengaluru, Karnataka
// Narrative: High-income earner, salary delayed on Jan 28th
// ===========================================================================

// ============ TYPE C: CORE IDENTITY & GOVERNANCE ============
class UserProfile {
  final String uuid;
  final String fullName;
  final String displayName;
  final DateTime dob;
  final String citizenship;
  final int sayIdTrustLevel;
  final String kycStatus;
  final LinkedIds linkedIds;
  final VoterStatus voterStatus;

  const UserProfile({
    required this.uuid,
    required this.fullName,
    required this.displayName,
    required this.dob,
    required this.citizenship,
    required this.sayIdTrustLevel,
    required this.kycStatus,
    required this.linkedIds,
    required this.voterStatus,
  });
}

class LinkedIds {
  final String aadhaarLast4;
  final String panHash;
  final String passportStatus;

  const LinkedIds({
    required this.aadhaarLast4,
    required this.panHash,
    required this.passportStatus,
  });
}

class VoterStatus {
  final bool registered;
  final String constituency;
  final DateTime lastVoted;

  const VoterStatus({
    required this.registered,
    required this.constituency,
    required this.lastVoted,
  });
}

// ============ TYPE B: FINANCE & WEALTH ============
class FinancePortfolio {
  final String walletId;
  final double currentBalance;
  final String currency;
  final double monthlyBurnRate;
  final int creditScore;
  final SalaryStatus salaryStatus;
  final List<StockHolding> holdings;
  final List<Subscription> subscriptions;

  const FinancePortfolio({
    required this.walletId,
    required this.currentBalance,
    required this.currency,
    required this.monthlyBurnRate,
    required this.creditScore,
    required this.salaryStatus,
    required this.holdings,
    required this.subscriptions,
  });

  double get runwayMonths => currentBalance / monthlyBurnRate;
}

class SalaryStatus {
  final String employer;
  final DateTime expectedDate;
  final DateTime lastReceived;
  final String status; // RECEIVED, PENDING, OVERDUE_CRITICAL

  const SalaryStatus({
    required this.employer,
    required this.expectedDate,
    required this.lastReceived,
    required this.status,
  });

  bool get isOverdue => status == 'OVERDUE_CRITICAL';
  int get daysOverdue {
    final now = DateTime(2026, 1, 28); // Demo date
    return now.difference(expectedDate).inDays;
  }
}

class StockHolding {
  final String ticker;
  final String name;
  final int qty;
  final double avgBuy;
  final double currentPrice;
  final double pnlPercent;

  const StockHolding({
    required this.ticker,
    required this.name,
    required this.qty,
    required this.avgBuy,
    required this.currentPrice,
    required this.pnlPercent,
  });

  double get currentValue => qty * currentPrice;
  double get investedValue => qty * avgBuy;
  double get pnlAbsolute => currentValue - investedValue;
}

class Subscription {
  final String name;
  final double cost;
  final String status; // ACTIVE, PAUSED, CANCELLED

  const Subscription({
    required this.name,
    required this.cost,
    required this.status,
  });
}

// ============ TYPE A: LIFESTYLE & CONSUMPTION ============
class LifestylePrefs {
  final StreamingProfile streamingProfile;
  final SocialStatus social;

  const LifestylePrefs({
    required this.streamingProfile,
    required this.social,
  });
}

class StreamingProfile {
  final String user;
  final String watchTimeBalance;
  final String currentBinge;
  final List<ContentRecommendation> recommendations;

  const StreamingProfile({
    required this.user,
    required this.watchTimeBalance,
    required this.currentBinge,
    required this.recommendations,
  });
}

class ContentRecommendation {
  final String title;
  final String genre;
  final String match;

  const ContentRecommendation({
    required this.title,
    required this.genre,
    required this.match,
  });
}

class SocialStatus {
  final String status;
  final String holoportationDevice;
  final List<RecentCall> recentCalls;

  const SocialStatus({
    required this.status,
    required this.holoportationDevice,
    required this.recentCalls,
  });
}

class RecentCall {
  final String name;
  final String type; // HOLO_3D, VIDEO, VOICE
  final String duration;

  const RecentCall({
    required this.name,
    required this.type,
    required this.duration,
  });
}

// ============ TYPE D: LEGAL & JUSTICE ============
class LegalRecord {
  final String status; // CLEAN, ACTIVE_CASES
  final List<ActiveCase> activeCases;

  const LegalRecord({
    required this.status,
    required this.activeCases,
  });
}

class ActiveCase {
  final String caseId;
  final String type;
  final String description;
  final double fineAmount;
  final DateTime issuedAt;
  final AiAnalysis aiAnalysis;

  const ActiveCase({
    required this.caseId,
    required this.type,
    required this.description,
    required this.fineAmount,
    required this.issuedAt,
    required this.aiAnalysis,
  });
}

class AiAnalysis {
  final double probabilityOfWin;
  final String defenseStrategy;
  final String actionTaken;

  const AiAnalysis({
    required this.probabilityOfWin,
    required this.defenseStrategy,
    required this.actionTaken,
  });
}

// ============ TYPE E: HEALTH (Vitality) ============
class HealthRecord {
  final String bloodType;
  final String insuranceId;
  final String emergencyContact;
  final List<HealthMetric> metrics;
  final List<MedicalHistory> history;

  const HealthRecord({
    required this.bloodType,
    required this.insuranceId,
    required this.emergencyContact,
    required this.metrics,
    required this.history,
  });
}

class HealthMetric {
  final String label;
  final String value;
  final String status; // NORMAL, WARNING, CRITICAL
  final String trend; // UP, DOWN, STABLE

  const HealthMetric({
    required this.label,
    required this.value,
    required this.status,
    required this.trend,
  });
}

class MedicalHistory {
  final String date;
  final String title;
  final String doctor;
  final String type;

  const MedicalHistory({
    required this.date,
    required this.title,
    required this.doctor,
    required this.type,
  });
}

// ============ TYPE F: EDUCATION & SKILLS ============
class AcademicTranscript {
  final String degree;
  final String almaMater;
  final Map<String, String> skillTree;
  final List<ActiveCourse> activeCourses;

  const AcademicTranscript({
    required this.degree,
    required this.almaMater,
    required this.skillTree,
    required this.activeCourses,
  });
}

class ActiveCourse {
  final String courseId;
  final String title;
  final int progress;
  final bool isJobCritical;

  const ActiveCourse({
    required this.courseId,
    required this.title,
    required this.progress,
    required this.isJobCritical,
  });
}

// ============ SYSTEM EVENTS ============
class SystemEvent {
  final String triggerId;
  final DateTime timestamp;
  final String targetUser;
  final String type;
  final EventPayload payload;

  const SystemEvent({
    required this.triggerId,
    required this.timestamp,
    required this.targetUser,
    required this.type,
    required this.payload,
  });
}

class EventPayload {
  final String message;
  final String severity; // LOW, MEDIUM, HIGH, CRITICAL
  final List<String> suggestedActions;

  const EventPayload({
    required this.message,
    required this.severity,
    required this.suggestedActions,
  });
}

// ===========================================================================
// HARD-CODED DEMO DATA FOR SYED YASIR ARAFAT
// ===========================================================================

class MockData {
  // ========== USER PROFILE (Type C) ==========
  static final userProfile = UserProfile(
    uuid: 'usr_88291_say_v6',
    fullName: 'Syed Yasir Arafat',
    displayName: 'Yasir',
    dob: DateTime(1997, 8, 14),
    citizenship: 'Indian',
    sayIdTrustLevel: 5,
    kycStatus: 'VERIFIED_PLATINUM',
    linkedIds: const LinkedIds(
      aadhaarLast4: '8821',
      panHash: 'cr7_encrypted_x99',
      passportStatus: 'ACTIVE_VALID_2032',
    ),
    voterStatus: VoterStatus(
      registered: true,
      constituency: 'Bangalore South',
      lastVoted: DateTime(2024, 5, 12),
    ),
  );

  // ========== FINANCE PORTFOLIO (Type B) ==========
  static final financePortfolio = FinancePortfolio(
    walletId: 'wal_b_2201',
    currentBalance: 142050.00,
    currency: 'INR',
    monthlyBurnRate: 45000.00,
    creditScore: 782,
    salaryStatus: SalaryStatus(
      employer: 'TechNova Solutions',
      expectedDate: DateTime(2026, 1, 25),
      lastReceived: DateTime(2025, 12, 25),
      status: 'OVERDUE_CRITICAL',
    ),
    holdings: const [
      StockHolding(
        ticker: 'SAYTECH',
        name: 'SAY Technologies',
        qty: 500,
        avgBuy: 120.50,
        currentPrice: 145.20,
        pnlPercent: 20.4,
      ),
      StockHolding(
        ticker: 'RELIANCE',
        name: 'Reliance Ind',
        qty: 50,
        avgBuy: 2400.00,
        currentPrice: 2380.00,
        pnlPercent: -0.8,
      ),
    ],
    subscriptions: const [
      Subscription(name: 'FlimXgo Premium', cost: 199, status: 'ACTIVE'),
      Subscription(name: 'Gym Pro', cost: 2000, status: 'ACTIVE'),
      Subscription(name: 'SAY Citizen', cost: 1499, status: 'ACTIVE'),
    ],
  );

  // ========== LIFESTYLE PREFS (Type A) ==========
  static const lifestylePrefs = LifestylePrefs(
    streamingProfile: StreamingProfile(
      user: 'Syed Yasir',
      watchTimeBalance: '42 Hours Remaining',
      currentBinge: 'Breaking Bad',
      recommendations: [
        ContentRecommendation(title: 'The Startup', genre: 'Drama', match: '98%'),
        ContentRecommendation(title: 'Black Mirror', genre: 'Sci-Fi', match: '95%'),
        ContentRecommendation(title: 'Scam 1992', genre: 'Bio', match: '92%'),
      ],
    ),
    social: SocialStatus(
      status: 'Online',
      holoportationDevice: 'iPhone 16 Pro',
      recentCalls: [
        RecentCall(name: 'Ammi', type: 'HOLO_3D', duration: '14m'),
        RecentCall(name: 'Broker (AI)', type: 'VOICE', duration: '2m'),
      ],
    ),
  );

  // ========== LEGAL RECORD (Type D) ==========
  static final legalRecord = LegalRecord(
    status: 'CLEAN',
    activeCases: [
      ActiveCase(
        caseId: 'KA01-2026-TRF-992',
        type: 'TRAFFIC_VIOLATION',
        description: 'Signal Jump at Silk Board Junction',
        fineAmount: 1000,
        issuedAt: DateTime(2026, 1, 15, 8, 30),
        aiAnalysis: const AiAnalysis(
          probabilityOfWin: 68.5,
          defenseStrategy: 'GPS_LOG_ERROR',
          actionTaken: 'CONTESTED_AUTO',
        ),
      ),
    ],
  );

  // ========== HEALTH RECORD (Type E) ==========
  static final healthRecord = HealthRecord(
    bloodType: 'O+',
    insuranceId: 'SAY-HEALTH-2026-X99',
    emergencyContact: '+91 9988776655 (Ammi)',
    metrics: const [
      HealthMetric(label: 'Heart Rate', value: '72 bpm', status: 'NORMAL', trend: 'STABLE'),
      HealthMetric(label: 'Sleep', value: '6h 30m', status: 'WARNING', trend: 'DOWN'),
      HealthMetric(label: 'Steps', value: '8,432', status: 'NORMAL', trend: 'UP'),
    ],
    history: const [
      MedicalHistory(
        date: '2025-11-12',
        title: 'Annual Checkup',
        doctor: 'Dr. AI (Apollo)',
        type: 'ROUTINE',
      ),
      MedicalHistory(
        date: '2025-08-05',
        title: 'Viral Fever',
        doctor: 'Dr. Sharma',
        type: 'ACUTE',
      ),
    ],
  );

  // ========== ACADEMIC TRANSCRIPT (Type F) ==========
  static const academicTranscript = AcademicTranscript(
    degree: 'B.Arch (Architecture)',
    almaMater: 'RV College',
    skillTree: {
      'Design': 'Level 8 (Master)',
      'Project_Mgmt': 'Level 5 (Pro)',
      'AI_Tools': 'Level 2 (Beginner)',
    },
    activeCourses: [
      ActiveCourse(
        courseId: 'AI_ARCH_101',
        title: 'Generative Design with AI',
        progress: 35,
        isJobCritical: true,
      ),
    ],
  );

  // ========== DEMO TRIGGER EVENT ==========
  static final salaryMissingEvent = SystemEvent(
    triggerId: 'EVT_SALARY_MISSING_001',
    timestamp: DateTime(2026, 1, 28, 9, 0),
    targetUser: 'usr_88291_say_v6',
    type: 'FINANCIAL_ANOMALY',
    payload: const EventPayload(
      message: "Regular salary deposit from 'TechNova' is 3 days overdue.",
      severity: 'HIGH',
      suggestedActions: [
        'ACTIVATE_AUSTERITY_MODE',
        'PAUSE_SUBSCRIPTIONS',
        'OPEN_GIG_HUB',
      ],
    ),
  );
}

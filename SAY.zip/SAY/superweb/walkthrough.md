# Superweb V2 - Digital Nation-State OS (Demo Walkthrough)

This document guides you through the extended features of Superweb, now available on **Flutter** and **Web**, including the new Type E (Health), Ghost Mode, and Z-Swipe gesture.

## 🚀 Running the App

### Flutter App
```bash
cd superweb
flutter run
```

### Web Version
Simply open `index.html` in any modern browser.

---

## 🆕 New V2 Features

### 1. Z-Swipe Gesture (AI Governor Trigger)
Instead of searching for menus, perform the **"Z-Swipe"**:
- **Action**: Trace a "Z" shape on the screen (Top-Left → Top-Right → Bottom-Left → Bottom-Right).
- **Result**: Triggers the **SAY-AI Governor** overlay or toggles **Ghost Mode**.
- **Use Case**: Quick access to critical privacy or legal tools.

### 2. Ghost Mode (Privacy)
- **Trigger**: Toggle via the Z-Swipe action or AI Overlay.
- **Visuals**:
  - Theme turns **Monochrome/White** (Privacy Shield).
  - "Verified" badge disappears.
  - Location tracking is disabled (simulated).
- **Pitch**: "A Faraday Cage for your data."

### 3. Type E: SAY Vitality (Health Module)
- **Access**: Tap the **Heart Icon (❤️)** in the navigation bar.
- **Features**:
  - Live Vitals Dashboard (Heart Rate, Sleep, Steps).
  - **Emergency ID**: Blood Type, Insurance, Emergency Contact.
  - **Panic Button**:
    - **Flutter**: Long-press the "HOLD" button.
    - **Web**: Click "🚨 PANIC".
    - **Result**: Simulates GPS broadcast, Flash Medical ID, and Unlock Emergency Funds.

---

## 🎬 Master Demo Script

### Scenario 1: The Salary Crisis (Original)
1.  **Start**: Green/Blue Theme.
2.  **Action**: Double-tap the Logo.
3.  **Result**: "Red Alert" Crisis Mode activates.
    - Salary Overdue logic triggers.
    - Type B shows "Austerity Mode".
    - Type F highlights "Job Critical" courses.

### Scenario 2: The Privacy Shield
1.  **Context**: "I feel like I'm being tracked..."
2.  **Action**: Swipe a "Z" on the screen (Flutter) or use Toggle (Web).
3.  **Result**: UI turns **Ghost White**. Toast confirms "Location Tracking Disabled."

### Scenario 3: The Medical Emergency
1.  **Context**: User is in danger.
2.  **Action**: Navigate to **Type E**.
3.  **Action**: Long-press "Panic Button".
4.  **Result**:
    - "MEDICAL EMERGENCY" Overlay appears.
    - Funds unlocked in Type B (Toast notification).
    - Authorities alerted.

---

## 🛠️ Implementation Details

### Flutter
- **`z_gesture_detector.dart`**: Custom widget for vector-based gesture recognition.
- **`TypeEScreen`**: dedicated Health module UI.
- **`AppTheme`**: Extended with Ghost Mode (Monochrome) palette.

### Web
- **`core.js`**:
  - Added `setupZGesture()` listener.
  - Added `getTypeEContent()` generator.
  - Added `toggleGhostMode()` CSS class toggler.
- **`main.css`**: added `.ghost-mode` override classes.

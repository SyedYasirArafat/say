/* ================================================================================
   SAY-AI GOVERNOR
   Cross-Module Intelligence & Orchestration Layer
   ================================================================================ */

// ================================================================================
// GOVERNOR STATE
// ================================================================================
const SAYGovernor = {
    isActive: true,
    watchingModules: ['a', 'b', 'c', 'd', 'f'],
    eventQueue: [],
    scenarios: {}
};

// ================================================================================
// SCENARIO DEFINITIONS
// ================================================================================
SAYGovernor.scenarios = {
    'job-loss': {
        name: 'Job Loss Safety Net',
        trigger: 'Salary deposit missing for 45+ days',
        actions: [
            { type: 'b', action: 'Activated Budget Mode - Auto-investing paused' },
            { type: 'f', action: 'Highlighted high-demand courses: AI, Cloud Computing' },
            { type: 'c', action: 'Pre-filled unemployment benefit form' },
            { type: 'a', action: 'Paused premium subscriptions, added free content' }
        ],
        notification: "We're here for you. 💪 Your budget is optimized for essentials. We've pre-filled your benefits form and found skill courses that are hiring NOW. Here's a free movie to lift your spirits! 🍿"
    },

    'test-fail': {
        name: 'Academic Intervention',
        trigger: 'Test score below passing threshold',
        actions: [
            { type: 'a', action: 'Reduced entertainment quota by 30%' },
            { type: 'b', action: 'Found available tutors on Gig-Hub (₹500/hr)' },
            { type: 'f', action: 'Unlocked remedial skill nodes, scheduled AI tutor' }
        ],
        notification: "We noticed that test was tough. 📚 We've adjusted your study plan and found you a great tutor. Complete 2 practice sessions to restore your entertainment time. You've got this! 💪"
    },

    'traffic-ticket': {
        name: 'Legal Preparation Advisor',
        trigger: 'Traffic violation notice received',
        actions: [
            { type: 'd', action: 'Generated AI defense brief, scheduled virtual hearing' },
            { type: 'c', action: 'Retrieved clean driving record as evidence' },
            { type: 'b', action: 'Reserved ₹5,000 legal contingency fund' },
            { type: 'f', action: 'Suggested Traffic Rules 101 course' }
        ],
        notification: "Traffic ticket received. Good news: Your clean record gives you a 62% chance of winning! 🎯 We've drafted a defense and scheduled a hearing. Review the brief or hire a lawyer for ₹3,000."
    },

    'purchase-guitar': {
        name: 'Contextual Recommendation',
        trigger: 'User purchased a guitar on FlimXgo Commerce',
        actions: [
            { type: 'f', action: 'Added "Guitar Mastery" skill tree to recommendations' },
            { type: 'a', action: 'Curated guitar tutorial playlist' }
        ],
        notification: "🎸 Nice purchase! We've added Guitar lessons to your Intellect feed. Want to start with 'Beginner Chords in 7 Days'? Your journey to rockstar begins now!"
    },

    'health-alert': {
        name: 'Health & Finance Sync',
        trigger: 'Unusual spending pattern on medical expenses',
        actions: [
            { type: 'b', action: 'Adjusted budget allocation for healthcare' },
            { type: 'c', action: 'Retrieved health insurance documents' },
            { type: 'f', action: 'Suggested wellness courses' }
        ],
        notification: "We noticed medical expenses. 🏥 Your health insurance docs are ready in GovConnect. Budget adjusted to prioritize healthcare. Take care of yourself!"
    }
};

// ================================================================================
// INITIALIZATION
// ================================================================================
function initSAYGovernor() {
    console.log('🤖 SAY-AI Governor initializing...');

    // Listen for module changes
    window.addEventListener('superweb:moduleChange', handleModuleChange);

    // Listen for user actions
    window.addEventListener('superweb:userAction', handleUserAction);

    // Start background monitoring
    startMonitoring();

    console.log('✅ SAY-AI Governor active');
}

// ================================================================================
// EVENT HANDLERS
// ================================================================================
function handleModuleChange(event) {
    const { type, module } = event.detail;
    logEvent('MODULE_SWITCH', { from: SAYGovernor.lastModule, to: type });
    SAYGovernor.lastModule = type;
}

function handleUserAction(event) {
    const { action, module, data } = event.detail;
    logEvent('USER_ACTION', { action, module, data });

    // Analyze action for cross-module triggers
    analyzeAction(action, module, data);
}

// ================================================================================
// SCENARIO TRIGGERS
// ================================================================================
function triggerScenario(scenarioId) {
    const scenario = SAYGovernor.scenarios[scenarioId];
    if (!scenario) {
        console.error(`Scenario ${scenarioId} not found`);
        return;
    }

    console.log(`🔔 SAY-AI Governor triggering: ${scenario.name}`);

    // Show cross-module action cascade
    showScenarioCascade(scenario);
}

function showScenarioCascade(scenario) {
    const toast = document.getElementById('ai-toast');
    const messageEl = toast.querySelector('.ai-toast-message');
    const titleEl = toast.querySelector('.ai-toast-title');

    // First: Show trigger message
    titleEl.textContent = `SAY-AI: ${scenario.name}`;
    messageEl.innerHTML = `<strong>Detected:</strong> ${scenario.trigger}<br><br>Initiating cross-module response...`;
    toast.classList.remove('hidden');

    // Then: Show each action with delay
    let delay = 1500;
    scenario.actions.forEach((action, index) => {
        setTimeout(() => {
            const typeInfo = window.SuperwebState.modules[action.type];
            messageEl.innerHTML = `<strong>[${typeInfo.name}]:</strong><br>${action.action}`;

            // Highlight the corresponding nav button
            highlightModule(action.type);
        }, delay);
        delay += 1200;
    });

    // Finally: Show unified notification
    setTimeout(() => {
        messageEl.innerHTML = scenario.notification;
        titleEl.textContent = 'SAY-AI Governor';

        // Reset all highlights
        document.querySelectorAll('.type-btn').forEach(btn => {
            btn.classList.remove('governor-highlight');
        });
    }, delay + 500);

    // Auto-hide after all actions
    setTimeout(() => {
        toast.classList.add('hidden');
    }, delay + 6000);
}

function highlightModule(type) {
    // Remove previous highlights
    document.querySelectorAll('.type-btn').forEach(btn => {
        btn.classList.remove('governor-highlight');
    });

    // Add highlight to current
    const btn = document.querySelector(`[data-type="${type}"]`);
    if (btn) {
        btn.classList.add('governor-highlight');
        btn.style.animation = 'governor-pulse 0.5s ease-out';
    }
}

// ================================================================================
// BACKGROUND MONITORING
// ================================================================================
function startMonitoring() {
    // Simulate continuous monitoring
    setInterval(() => {
        checkFinancePatterns();
        checkEducationProgress();
        checkGovernmentDeadlines();
    }, 60000); // Every minute
}

function checkFinancePatterns() {
    // In real implementation: analyze spending patterns, income gaps, etc.
}

function checkEducationProgress() {
    // In real implementation: track learning velocity, suggest interventions
}

function checkGovernmentDeadlines() {
    // In real implementation: monitor document expiry, form deadlines
}

// ================================================================================
// CROSS-MODULE DATA REQUESTS
// ================================================================================
function requestCrossModuleData(fromType, toType, dataType) {
    // Privacy matrix enforcement
    const privacyMatrix = {
        'a': { 'b': false, 'c': false, 'd': false, 'f': 'progress_only' },
        'b': { 'a': false, 'c': 'kyc_only', 'd': 'case_refs', 'f': false },
        'c': { 'a': false, 'b': 'tax_reports', 'd': 'convictions', 'f': 'certifications' },
        'd': { 'a': false, 'b': 'fraud_flags', 'c': 'id_verify', 'f': false },
        'f': { 'a': false, 'b': false, 'c': 'age_verify', 'd': false }
    };

    const access = privacyMatrix[fromType]?.[toType];

    if (access === false) {
        console.warn(`🔒 Access DENIED: ${fromType} cannot access ${toType}`);
        return null;
    }

    console.log(`✅ Access GRANTED: ${fromType} → ${toType} (${access})`);
    return { access: access, data: {} }; // Placeholder
}

// ================================================================================
// EVENT LOGGING
// ================================================================================
function logEvent(eventType, data) {
    const event = {
        timestamp: new Date().toISOString(),
        type: eventType,
        data: data
    };

    SAYGovernor.eventQueue.push(event);

    // Keep only last 100 events
    if (SAYGovernor.eventQueue.length > 100) {
        SAYGovernor.eventQueue.shift();
    }

    console.log('📊 Governor Event:', event);
}

// ================================================================================
// ANALYSIS ENGINE
// ================================================================================
function analyzeAction(action, module, data) {
    // Pattern matching for auto-triggers
    const patterns = [
        {
            pattern: { action: 'purchase', module: 'a', category: 'instrument' },
            scenario: 'purchase-guitar'
        },
        {
            pattern: { action: 'test_result', module: 'f', score: '<40' },
            scenario: 'test-fail'
        },
        {
            pattern: { action: 'salary_missing', module: 'b', days: '>45' },
            scenario: 'job-loss'
        }
    ];

    // Check patterns (simplified)
    patterns.forEach(p => {
        if (matchPattern(p.pattern, { action, module, ...data })) {
            triggerScenario(p.scenario);
        }
    });
}

function matchPattern(pattern, data) {
    // Simplified pattern matching
    return pattern.action === data.action && pattern.module === data.module;
}

// ================================================================================
// INITIALIZATION ON LOAD
// ================================================================================
document.addEventListener('DOMContentLoaded', () => {
    initSAYGovernor();
});

// Add CSS for governor highlight
const style = document.createElement('style');
style.textContent = `
    .governor-highlight {
        border-color: #f59e0b !important;
        box-shadow: 0 0 30px rgba(245, 158, 11, 0.5) !important;
    }
    
    @keyframes governor-pulse {
        0% { transform: scale(1); }
        50% { transform: scale(1.02); }
        100% { transform: scale(1); }
    }
`;
document.head.appendChild(style);

// Export for global access
window.SAYGovernor = SAYGovernor;
window.triggerScenario = triggerScenario;

/* ================================================================================
   SUPERWEB CORE.JS
   Module Loader & Event Router
   ================================================================================ */

// ================================================================================
// STATE MANAGEMENT
// ================================================================================
const SuperwebState = {
    currentModule: 'a',
    modules: {
        a: { name: 'FlimXgo', loaded: false, color: '#ec4899' },
        b: { name: 'SAY Finance', loaded: false, color: '#10b981' },
        c: { name: 'GovConnect', loaded: false, color: '#3b82f6' },
        d: { name: 'Justice OS', loaded: false, color: '#8b5cf6' },
        f: { name: 'Intellect', loaded: false, color: '#06b6d4' },
        e: { name: 'SAY Vitality', loaded: false, color: '#ef4444' }
    },
    user: {
        id: 'SAY-USER-001',
        name: 'SAY Citizen',
        tier: 'pro',
        balance: 125000,
        xp: 4200
    }
};

// ================================================================================
// INITIALIZATION
// ================================================================================
function initSuperShell() {
    console.log('🚀 Superweb Super-Shell initializing...');

    // Setup navigation handlers
    setupNavigation();

    // Load default module (Type A)
    loadModule('a');

    // Initialize keyboard shortcuts
    setupKeyboardShortcuts();

    // Initialize Z-Gesture Listener
    setupZGesture();

    console.log('✅ Super-Shell initialized');
}

// ================================================================================
// NAVIGATION
// ================================================================================
function setupNavigation() {
    const navButtons = document.querySelectorAll('.type-btn');

    navButtons.forEach(btn => {
        btn.addEventListener('click', () => {
            const type = btn.dataset.type;
            switchModule(type);
        });
    });
}

function switchModule(type) {
    if (type === SuperwebState.currentModule) return;

    // Update active state
    document.querySelectorAll('.type-btn').forEach(btn => {
        btn.classList.remove('active');
    });
    document.querySelector(`[data-type="${type}"]`).classList.add('active');

    // Load the module
    loadModule(type);

    // Update state
    SuperwebState.currentModule = type;

    // Emit event for SAY-AI Governor
    emitModuleChange(type);
}

// ================================================================================
// MODULE LOADER (Lazy Loading)
// ================================================================================
async function loadModule(type) {
    const container = document.getElementById('module-content');
    const loading = document.getElementById('module-loading');
    const loadingName = document.getElementById('loading-module-name');

    // Show loading state
    loadingName.textContent = SuperwebState.modules[type].name;
    loading.classList.remove('hidden');
    container.innerHTML = '';

    // Simulate network delay (in real app, this fetches from server)
    await delay(600);

    // Load module content
    const moduleHTML = getModuleContent(type);

    // Hide loading, show content
    loading.classList.add('hidden');
    container.innerHTML = moduleHTML;

    // Initialize module-specific scripts
    initModuleScripts(type);

    // Mark as loaded
    SuperwebState.modules[type].loaded = true;

    console.log(`📦 Module ${SuperwebState.modules[type].name} loaded`);
}

function getModuleContent(type) {
    const modules = {
        a: getTypeAContent(),
        b: getTypeBContent(),
        c: getTypeCContent(),
        d: getTypeDContent(),
        f: getTypeFContent(),
        e: getTypeEContent()
    };
    return modules[type] || '<p>Module not found</p>';
}

// ================================================================================
// TYPE A: FLIMXGO (Lifestyle & Consumption)
// ================================================================================
function getTypeAContent() {
    return `
        <div class="module-header">
            <div class="module-title">
                <span class="module-icon">📺</span>
                <div>
                    <h1>FlimXgo</h1>
                    <p class="text-muted">Live, Watch, Connect, Shop</p>
                </div>
            </div>
            <div class="module-actions">
                <button class="btn btn-outline">🎬 Watchlist</button>
                <button class="btn">+ Add Time Pass</button>
            </div>
        </div>
        
        <!-- Featured Content -->
        <section class="section">
            <h2 class="section-title">🔥 Trending Now</h2>
            <div class="content-grid">
                ${generateContentCards()}
            </div>
        </section>
        
        <!-- Continue Watching -->
        <section class="section">
            <h2 class="section-title">▶️ Continue Watching</h2>
            <div class="content-row">
                ${generateContinueWatching()}
            </div>
        </section>
        
        <!-- VidKing Test Player -->
        <section class="section">
            <h2 class="section-title">🧪 VidKing Test Player</h2>
            <div class="vidking-container" style="background: #000; padding: 20px; border-radius: 12px;">
                 <p class="text-muted" style="margin-bottom: 10px;">Test FlimXgo Integration</p>
                 <div style="position: relative; padding-bottom: 56.25%; height: 0; overflow: hidden;">
                    <iframe src="https://vidking.net" style="position: absolute; top: 0; left: 0; width: 100%; height: 100%; border: 0;" allowfullscreen></iframe>
                </div>
            </div>
        </section>
    `;
}

function generateContentCards() {
    const content = [
        { title: 'Inception 2', genre: 'Sci-Fi', rating: '9.2', provider: 'Netflix', image: '🎬' },
        { title: 'The Crown S7', genre: 'Drama', rating: '8.8', provider: 'Hotstar', image: '👑' },
        { title: 'Tech Giants', genre: 'Documentary', rating: '9.0', provider: 'YouTube', image: '💻' },
        { title: 'Mumbai Stories', genre: 'Thriller', rating: '8.5', provider: 'Prime', image: '🌆' },
        { title: 'Cosmic Horizons', genre: 'Sci-Fi', rating: '9.4', provider: 'Netflix', image: '🚀' },
        { title: 'The Algorithm', genre: 'Tech Drama', rating: '8.9', provider: 'Prime', image: '🤖' }
    ];

    return content.map(item => `
        <div class="content-card">
            <div class="content-poster">${item.image}</div>
            <div class="content-info">
                <div class="content-title">${item.title}</div>
                <div class="content-meta">
                    <span class="content-genre">${item.genre}</span>
                    <span class="content-rating">⭐ ${item.rating}</span>
                </div>
                <div class="content-provider">${item.provider}</div>
            </div>
            <button class="content-play-btn">▶</button>
        </div>
    `).join('');
}

function generateContinueWatching() {
    const items = [
        { title: 'Breaking Bad S3E7', progress: 67 },
        { title: 'Planet Earth III', progress: 23 },
        { title: 'The Mandalorian', progress: 89 }
    ];

    return items.map(item => `
        <div class="continue-card">
            <div class="continue-poster">🎥</div>
            <div class="continue-progress" style="width: ${item.progress}%"></div>
            <div class="continue-title">${item.title}</div>
        </div>
    `).join('');
}

// ================================================================================
// TYPE B: SAY FINANCE (Economy & Wealth)
// ================================================================================
function getTypeBContent() {
    return `
        <div class="module-header">
            <div class="module-title">
                <span class="module-icon">💰</span>
                <div>
                    <h1>SAY Finance</h1>
                    <p class="text-muted">Grow, Trade, Earn</p>
                </div>
            </div>
            <div class="module-actions">
                <button class="btn btn-outline">📊 Analytics</button>
                <button class="btn">+ Add Funds</button>
            </div>
        </div>
        
        <!-- Portfolio Overview -->
        <div class="finance-grid">
            <div class="card portfolio-card">
                <h3>Portfolio Value</h3>
                <div class="portfolio-value">₹${SuperwebState.user.balance.toLocaleString()}</div>
                <div class="portfolio-change positive">+₹12,340 (10.9%) today</div>
                <div class="portfolio-chart">${generateMiniChart()}</div>
            </div>
            
            <div class="card">
                <h3>Wallet</h3>
                <div class="wallet-balance">₹45,230</div>
                <div class="wallet-actions">
                    <button class="wallet-btn">Send</button>
                    <button class="wallet-btn">Receive</button>
                    <button class="wallet-btn">UPI</button>
                </div>
            </div>
            
            <div class="card">
                <h3>AI-CFO Insights</h3>
                <div class="ai-insight">
                    <span class="ai-icon">🤖</span>
                    <p>You have ₹15,000 "lazy money" sitting idle. Move to overnight fund for ₹41/day extra?</p>
                </div>
                <button class="btn" style="width: 100%; margin-top: 12px;">Auto-Optimize</button>
            </div>
        </div>
        
        <!-- Copy Trading Section -->
        <section class="section">
            <h2 class="section-title">🏆 Top Traders to Copy</h2>
            <div class="traders-grid">
                ${generateTraderCards()}
            </div>
        </section>
        
        <!-- Gig-Hub Preview -->
        <section class="section">
            <h2 class="section-title">💼 Gig-Hub: Hot Jobs</h2>
            <div class="gig-list">
                ${generateGigCards()}
            </div>
        </section>
    `;
}

function generateMiniChart() {
    return `<svg viewBox="0 0 200 60" class="mini-chart">
        <polyline 
            points="0,50 20,45 40,48 60,30 80,35 100,20 120,25 140,15 160,18 180,10 200,5" 
            fill="none" 
            stroke="#10b981" 
            stroke-width="2"
        />
        <linearGradient id="chartGradient" x1="0%" y1="0%" x2="0%" y2="100%">
            <stop offset="0%" style="stop-color:#10b981;stop-opacity:0.3" />
            <stop offset="100%" style="stop-color:#10b981;stop-opacity:0" />
        </linearGradient>
        <polygon 
            points="0,50 20,45 40,48 60,30 80,35 100,20 120,25 140,15 160,18 180,10 200,5 200,60 0,60" 
            fill="url(#chartGradient)"
        />
    </svg>`;
}

function generateTraderCards() {
    const traders = [
        { name: 'RakeshJ', returns: '+234%', followers: '12.4K', avatar: '👨‍💼' },
        { name: 'FinanceGuru', returns: '+189%', followers: '8.7K', avatar: '📈' },
        { name: 'TechTrader', returns: '+156%', followers: '5.2K', avatar: '💹' }
    ];

    return traders.map(t => `
        <div class="trader-card card">
            <div class="trader-avatar">${t.avatar}</div>
            <div class="trader-info">
                <div class="trader-name">${t.name}</div>
                <div class="trader-followers">${t.followers} followers</div>
            </div>
            <div class="trader-returns">${t.returns}</div>
            <button class="btn">Copy</button>
        </div>
    `).join('');
}

function generateGigCards() {
    const gigs = [
        { title: 'React Native App', budget: '₹80,000', time: '2 weeks', urgent: true },
        { title: 'Logo Design', budget: '₹5,000', time: '3 days', urgent: false },
        { title: 'Data Analysis', budget: '₹25,000', time: '1 week', urgent: true }
    ];

    return gigs.map(g => `
        <div class="gig-card card">
            <div class="gig-info">
                <div class="gig-title">${g.title} ${g.urgent ? '<span class="urgent-badge">🔥 Urgent</span>' : ''}</div>
                <div class="gig-meta">${g.time} • Instant Payout</div>
            </div>
            <div class="gig-budget">${g.budget}</div>
            <button class="btn btn-outline">Apply</button>
        </div>
    `).join('');
}

// ================================================================================
// TYPE C: GOVCONNECT (Citizen & Government)
// ================================================================================
function getTypeCContent() {
    return `
        <div class="module-header">
            <div class="module-title">
                <span class="module-icon">🏛️</span>
                <div>
                    <h1>GovConnect</h1>
                    <p class="text-muted">Identify, Vote, Access</p>
                </div>
            </div>
            <div class="module-actions">
                <button class="btn btn-outline">📄 My Documents</button>
                <button class="btn">🗳️ Vote Now</button>
            </div>
        </div>
        
        <!-- SAY-ID Card -->
        <div class="say-id-card">
            <div class="id-header">
                <span class="id-badge">VERIFIED ✓</span>
                <span class="id-type">SAY-ID</span>
            </div>
            <div class="id-photo">👤</div>
            <div class="id-details">
                <div class="id-name">${SuperwebState.user.name}</div>
                <div class="id-number">SAY-2026-XXXX-XXXX</div>
                <div class="id-meta">
                    <span>Trust Level: 5/5</span>
                    <span>Aadhaar Linked ✓</span>
                </div>
            </div>
            <div class="id-qr">📱</div>
        </div>
        
        <!-- Document Locker -->
        <section class="section">
            <h2 class="section-title">🔐 Document Locker</h2>
            <div class="grid grid-4">
                ${generateDocumentCards()}
            </div>
        </section>
        
        <!-- Micro-Democracy -->
        <section class="section">
            <h2 class="section-title">🗳️ Active Votes</h2>
            <div class="vote-list">
                ${generateVoteCards()}
            </div>
        </section>
        
        <!-- Pending Forms -->
        <section class="section">
            <h2 class="section-title">📝 Forms Ready for Auto-Submit</h2>
            <div class="form-card card">
                <div class="form-icon">📋</div>
                <div class="form-info">
                    <div class="form-title">Passport Renewal Application</div>
                    <div class="form-status">100% auto-filled • Ready to submit</div>
                </div>
                <button class="btn">Review & Submit</button>
            </div>
        </section>
    `;
}

function generateDocumentCards() {
    const docs = [
        { name: 'Aadhaar Card', icon: '🪪', status: 'Verified' },
        { name: 'PAN Card', icon: '💳', status: 'Verified' },
        { name: 'Passport', icon: '📕', status: 'Expiring Soon' },
        { name: 'Driving License', icon: '🚗', status: 'Verified' }
    ];

    return docs.map(d => `
        <div class="doc-card card">
            <div class="doc-icon">${d.icon}</div>
            <div class="doc-name">${d.name}</div>
            <div class="doc-status ${d.status === 'Verified' ? 'verified' : 'warning'}">${d.status}</div>
        </div>
    `).join('');
}

function generateVoteCards() {
    const votes = [
        { topic: 'Park Renovation in Sector 21', deadline: '2 days left', votes: '1,234' },
        { topic: 'New Bus Route Proposal', deadline: '5 days left', votes: '856' }
    ];

    return votes.map(v => `
        <div class="vote-card card">
            <div class="vote-info">
                <div class="vote-topic">${v.topic}</div>
                <div class="vote-meta">${v.votes} votes • ${v.deadline}</div>
            </div>
            <div class="vote-actions">
                <button class="vote-btn yes">👍 Yes</button>
                <button class="vote-btn no">👎 No</button>
            </div>
        </div>
    `).join('');
}

// ================================================================================
// TYPE D: JUSTICE OS (Fairness & Law)
// ================================================================================
function getTypeDContent() {
    return `
        <div class="module-header">
            <div class="module-title">
                <span class="module-icon">⚖️</span>
                <div>
                    <h1>Justice OS</h1>
                    <p class="text-muted">Resolve, Protect, Predict</p>
                </div>
            </div>
            <div class="module-actions">
                <button class="btn btn-outline">📁 My Cases</button>
                <button class="btn">⚡ Quick Resolve</button>
            </div>
        </div>
        
        <!-- Case Simulator -->
        <div class="case-simulator card">
            <h3>🔮 AI Case Prediction</h3>
            <p class="text-muted">Enter your case details and get instant analysis</p>
            <div class="simulator-input">
                <select class="case-type-select">
                    <option>Traffic Violation</option>
                    <option>Consumer Complaint</option>
                    <option>Property Dispute</option>
                    <option>Employment Issue</option>
                </select>
                <button class="btn">Analyze Case</button>
            </div>
            <div class="prediction-result">
                <div class="prediction-gauge">
                    <div class="gauge-fill" style="width: 72%"></div>
                </div>
                <div class="prediction-text">
                    <span class="prediction-percent">72%</span>
                    <span>Probability of favorable outcome</span>
                </div>
            </div>
        </div>
        
        <!-- Active Cases -->
        <section class="section">
            <h2 class="section-title">📋 Your Cases</h2>
            <div class="cases-list">
                ${generateCaseCards()}
            </div>
        </section>
        
        <!-- ODR Section -->
        <section class="section">
            <h2 class="section-title">🤝 Online Dispute Resolution</h2>
            <div class="odr-card card">
                <div class="odr-icon">💬</div>
                <div class="odr-info">
                    <h4>Settle disputes without court</h4>
                    <p class="text-muted">AI-mediated resolution in under 15 minutes</p>
                </div>
                <button class="btn">Start ODR Session</button>
            </div>
        </section>
    `;
}

function generateCaseCards() {
    const cases = [
        { id: 'TRF-2024-0234', type: 'Traffic Violation', status: 'Hearing Scheduled', date: 'Jan 25, 2026', prediction: 72 },
        { id: 'CON-2024-0156', type: 'Consumer Complaint', status: 'Under Review', date: 'Jan 20, 2026', prediction: 85 }
    ];

    return cases.map(c => `
        <div class="case-card card">
            <div class="case-header">
                <span class="case-id">${c.id}</span>
                <span class="case-status">${c.status}</span>
            </div>
            <div class="case-type">${c.type}</div>
            <div class="case-meta">
                <span>📅 ${c.date}</span>
                <span class="case-prediction">🔮 ${c.prediction}% win probability</span>
            </div>
            <div class="case-actions">
                <button class="btn btn-outline">View Details</button>
                <button class="btn">Join Hearing</button>
            </div>
        </div>
    `).join('');
}

// ================================================================================
// TYPE F: INTELLECT (Education & Growth)
// ================================================================================
function getTypeFContent() {
    return `
        <div class="module-header">
            <div class="module-title">
                <span class="module-icon">📚</span>
                <div>
                    <h1>SAY Intellect</h1>
                    <p class="text-muted">Learn, Evolve, Skill Up</p>
                </div>
            </div>
            <div class="module-actions">
                <button class="btn btn-outline">🎯 My Goals</button>
                <button class="btn">🚀 Start Learning</button>
            </div>
        </div>
        
        <!-- XP Progress -->
        <div class="xp-banner">
            <div class="xp-info">
                <div class="xp-level">Level 12</div>
                <div class="xp-title">Intermediate Developer</div>
            </div>
            <div class="xp-bar-container">
                <div class="xp-bar">
                    <div class="xp-fill" style="width: 68%"></div>
                </div>
                <div class="xp-text">${SuperwebState.user.xp} / 6000 XP</div>
            </div>
        </div>
        
        <!-- Skill Trees -->
        <section class="section">
            <h2 class="section-title">🌳 Skill Trees</h2>
            <div class="skill-trees-grid">
                ${generateSkillTreeCards()}
            </div>
        </section>
        
        <!-- Continue Learning -->
        <section class="section">
            <h2 class="section-title">📖 Continue Learning</h2>
            <div class="course-list">
                ${generateCourseCards()}
            </div>
        </section>
        
        <!-- VR Labs -->
        <section class="section">
            <h2 class="section-title">🥽 VR Labs</h2>
            <div class="vr-card card">
                <div class="vr-preview">🔬</div>
                <div class="vr-info">
                    <h4>Chemistry Lab: Organic Reactions</h4>
                    <p class="text-muted">Safe, immersive experiments in Virtual Reality</p>
                </div>
                <button class="btn">Enter VR Lab</button>
            </div>
        </section>
    `;
}

function generateSkillTreeCards() {
    const trees = [
        { name: 'Programming', progress: 78, nodes: 24, icon: '💻' },
        { name: 'Data Science', progress: 45, nodes: 18, icon: '📊' },
        { name: 'Finance', progress: 62, nodes: 15, icon: '💰' },
        { name: 'Communication', progress: 89, nodes: 12, icon: '🗣️' }
    ];

    return trees.map(t => `
        <div class="skill-tree-card card">
            <div class="skill-icon">${t.icon}</div>
            <div class="skill-name">${t.name}</div>
            <div class="skill-progress">
                <div class="skill-bar">
                    <div class="skill-fill" style="width: ${t.progress}%"></div>
                </div>
                <span>${t.progress}%</span>
            </div>
            <div class="skill-nodes">${t.nodes} nodes unlocked</div>
        </div>
    `).join('');
}

function generateCourseCards() {
    const courses = [
        { title: 'React Advanced Patterns', progress: 67, next: 'useReducer Deep Dive' },
        { title: 'Machine Learning Basics', progress: 23, next: 'Linear Regression' }
    ];

    return courses.map(c => `
        <div class="course-card card">
            <div class="course-info">
                <div class="course-title">${c.title}</div>
                <div class="course-next">Next: ${c.next}</div>
            </div>
            <div class="course-progress-container">
                <div class="course-progress-bar">
                    <div class="course-progress-fill" style="width: ${c.progress}%"></div>
                </div>
                <span>${c.progress}%</span>
            </div>
            <button class="btn">Continue</button>
        </div>
    `).join('');
}

// ================================================================================
// MODULE-SPECIFIC INITIALIZATION
// ================================================================================
function initModuleScripts(type) {
    switch (type) {
        case 'a':
            initFlimXgo();
            break;
        case 'b':
            initFinance();
            break;
        case 'c':
            initGovConnect();
            break;
        case 'd':
            initJusticeOS();
            break;
        case 'f':
            initIntellect();
            break;
        case 'e':
            initVitality();
            break;
    }
}

function initFlimXgo() {
    // Add click handlers for content cards
    document.querySelectorAll('.content-card').forEach(card => {
        card.addEventListener('click', () => {
            showAIToast('🎬 Starting playback... Time Pass: 47h 22m remaining');
        });
    });
}

function initFinance() {
    // Portfolio animations, etc.
}

function initGovConnect() {
    // Document interactions
}

function initJusticeOS() {
    // Case prediction handlers
}

function initIntellect() {
    // Skill tree interactions
}

// ================================================================================
// EVENT SYSTEM (Cross-Module Communication)
// ================================================================================
function emitModuleChange(type) {
    const event = new CustomEvent('superweb:moduleChange', {
        detail: { type, module: SuperwebState.modules[type] }
    });
    window.dispatchEvent(event);
}

function emitEvent(eventName, data) {
    const event = new CustomEvent(`superweb:${eventName}`, { detail: data });
    window.dispatchEvent(event);
}

// ================================================================================
// KEYBOARD SHORTCUTS
// ================================================================================
function setupKeyboardShortcuts() {
    document.addEventListener('keydown', (e) => {
        // Cmd/Ctrl + K for search
        if ((e.metaKey || e.ctrlKey) && e.key === 'k') {
            e.preventDefault();
            document.querySelector('.search-input').focus();
        }

        // Number keys for quick module switch
        if (e.key >= '1' && e.key <= '5' && !e.target.matches('input, textarea')) {
            const types = ['a', 'b', 'c', 'd', 'f'];
            switchModule(types[parseInt(e.key) - 1]);
        }
    });
}

// ================================================================================
// UI HELPERS
// ================================================================================
function toggleRightPanel() {
    const shell = document.querySelector('.super-shell');
    const panel = document.getElementById('right-panel');
    shell.classList.toggle('panel-open');
    panel.classList.toggle('open');
}

function showAIToast(message) {
    const toast = document.getElementById('ai-toast');
    const messageEl = toast.querySelector('.ai-toast-message');
    messageEl.textContent = message;
    toast.classList.remove('hidden');

    // Auto-hide after 5 seconds
    setTimeout(() => {
        toast.classList.add('hidden');
    }, 5000);
}

function closeAIToast() {
    document.getElementById('ai-toast').classList.add('hidden');
}

// ================================================================================
// UTILITIES
// ================================================================================
function delay(ms) {
    return new Promise(resolve => setTimeout(resolve, ms));
}

// Export for global access
window.SuperwebState = SuperwebState;
window.switchModule = switchModule;
window.showAIToast = showAIToast;
window.closeAIToast = closeAIToast;
window.toggleRightPanel = toggleRightPanel;
// ================================================================================
// TYPE E: VITALITY (Health & Emergency)
// ================================================================================
function getTypeEContent() {
    return `
        <div class="module-header">
            <div class="module-title">
                <span class="module-icon">❤️</span>
                <div>
                    <h1>SAY Vitality</h1>
                    <p class="text-muted">Health, Emergency, Insurance</p>
                </div>
            </div>
            <div class="module-actions">
                <button class="btn btn-outline">🏥 Consult</button>
                <button class="btn panic-btn" onclick="triggerPanicMode()">🚨 PANIC</button>
            </div>
        </div>

        <!-- Vital Stats -->
        <section class="section">
            <h2 class="section-title">🩺 Live Vitals</h2>
            <div class="grid grid-3">
                <div class="card text-center">
                    <div class="text-muted">Heart Rate</div>
                    <div class="text-accent" style="font-size: 1.5rem; font-weight: bold;">72 bpm</div>
                    <div class="text-muted" style="font-size: 0.8rem;">Stable</div>
                </div>
                <div class="card text-center">
                    <div class="text-muted">Sleep</div>
                    <div class="text-warning" style="font-size: 1.5rem; font-weight: bold;">6h 30m</div>
                    <div class="text-muted" style="font-size: 0.8rem;">Needs Improvement</div>
                </div>
                <div class="card text-center">
                    <div class="text-muted">Steps</div>
                    <div class="text-accent" style="font-size: 1.5rem; font-weight: bold;">8,432</div>
                    <div class="text-muted" style="font-size: 0.8rem;">On Track</div>
                </div>
            </div>
        </section>

        <!-- Emergency ID -->
         <section class="section">
            <h2 class="section-title">🆔 Emergency ID Card</h2>
            <div class="card" style="display: flex; gap: 20px; align-items: center;">
                <div style="background: #ef4444; width: 60px; height: 60px; border-radius: 50%; display: flex; align-items: center; justify-content: center; font-size: 1.5rem;">🏥</div>
                <div>
                    <div><strong>Blood Type:</strong> O+</div>
                    <div><strong>Insurance:</strong> SAY-HEALTH-2026</div>
                    <div><strong>Emergency Contact:</strong> Ammi (+91 9988776655)</div>
                </div>
            </div>
        </section>
    `;
}

function initVitality() {
    //
}

function triggerPanicMode() {
    showAIToast("🚨 PANIC MODE ACTIVATED: GPS Sent to Police");
    setTimeout(() => showAIToast("🏥 Medical ID Flashing on Lock Screen"), 2000);
}

// ================================================================================
// Z-GESTURE & GHOST MODE
// ================================================================================

let points = [];
function setupZGesture() {
    document.addEventListener('mousemove', (e) => {
        points.push({ x: e.clientX, y: e.clientY, t: Date.now() });
        if (points.length > 100) points.shift();

        detectZ();
    });
}

function detectZ() {
    if (points.length < 50) return;

    // We analyze the stored points to find a Z shape
    // A Z shape consists of 3 segments:
    // 1. Top-Left -> Top-Right (Horizontal, rightward)
    // 2. Top-Right -> Bottom-Left (Diagonal, left-downward)
    // 3. Bottom-Left -> Bottom-Right (Horizontal, rightward)

    // 1. Get bounds and time duration to filter out accidental movements
    const start = points[0];
    const end = points[points.length - 1];
    const duration = end.t - start.t;

    // Z-Gesture should be quick but not instant (e.g. 500ms - 2000ms)
    if (duration < 300 || duration > 3000) return;

    // 2. Simplified Vector Analysis
    // We split the path into 3 chunks and check the general direction of each

    const chunk1EndIndex = Math.floor(points.length * 0.33);
    const chunk2EndIndex = Math.floor(points.length * 0.66);

    const pStart = points[0];
    const pMid1 = points[chunk1EndIndex];
    const pMid2 = points[chunk2EndIndex];
    const pEnd = points[points.length - 1];

    // Vectors
    const v1 = { dx: pMid1.x - pStart.x, dy: pMid1.y - pStart.y };
    const v2 = { dx: pMid2.x - pMid1.x, dy: pMid2.y - pMid1.y };
    const v3 = { dx: pEnd.x - pMid2.x, dy: pEnd.y - pMid2.y };

    // Logic Checks:
    // Seg 1 (Top Bar): Moves Right (+dx), relatively flat (dy is small compared to dx)
    const isSeg1Right = v1.dx > 50 && Math.abs(v1.dy) < (Math.abs(v1.dx) * 0.6);

    // Seg 2 (Diagonal): Moves Left (-dx) and Down (+dy)
    const isSeg2Diagonal = v2.dx < -50 && v2.dy > 50;

    // Seg 3 (Bottom Bar): Moves Right (+dx), relatively flat
    const isSeg3Right = v3.dx > 50 && Math.abs(v3.dy) < (Math.abs(v3.dx) * 0.6);

    if (isSeg1Right && isSeg2Diagonal && isSeg3Right) {
        // Debounce: verify we haven't triggered recently
        const now = Date.now();
        if (now - lastTriggerDiff > 3000) {
            lastTriggerDiff = now;
            console.log("⚡ Z-Gesture Detected!");
            toggleGhostMode();

            // Clear points to prevent double trigger
            points = [];
        }
    }


    let lastTriggerDiff = 0;

    function toggleGhostMode() {
        document.body.classList.toggle('ghost-mode');
        const isGhost = document.body.classList.contains('ghost-mode');

        if (isGhost) {
            showAIToast("👻 Ghost Mode: Privacy Shield Active. Location Off.");
        } else {
            showAIToast("🔵 Ghost Mode Deactivated. Services Restored.");
        }
    }

    // Global exposure
    window.triggerPanicMode = triggerPanicMode;
    window.toggleGhostMode = toggleGhostMode;
    window.initSuperShell = initSuperShell; // Re-export as we modified it
